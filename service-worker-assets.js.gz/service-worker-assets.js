self.assetsManifest = {
  "version": "7ErhpGk+",
  "assets": [
    {
      "hash": "sha256-IdQk7PSAjWg2nyye6IkiPavaxEFsMHTLdOGbicsmo7I=",
      "url": "BlazorWasmPreRendering.Build.9609fvaqjm.lib.module.js"
    },
    {
      "hash": "sha256-MASABpB4tYktI2Oitl4t+78w/lyA+D7b/s9GEP0JOGI=",
      "url": "_content/MudBlazor.Markdown/MudBlazor.Markdown.MathJax.min.js"
    },
    {
      "hash": "sha256-SejBwCUsA4ujIoauJtLZITlszOT2DspUOL0rbOBc8zw=",
      "url": "_content/MudBlazor.Markdown/MudBlazor.Markdown.min.css"
    },
    {
      "hash": "sha256-ra3qQZZqtyuTWkXazKjNXaizfWq9nIKfEmL3xutdsvA=",
      "url": "_content/MudBlazor.Markdown/MudBlazor.Markdown.min.js"
    },
    {
      "hash": "sha256-4CcabSFuAiMPemBJXz/YPL4Buv0IsfEBslZtIotn9yk=",
      "url": "_content/MudBlazor.Markdown/code-styles/a11y-dark.min.css"
    },
    {
      "hash": "sha256-WNBlCCi9aPAy7fogW5I6VZaxe8dKAZ4yhAAzB9ZfqtQ=",
      "url": "_content/MudBlazor.Markdown/code-styles/a11y-light.min.css"
    },
    {
      "hash": "sha256-2a9PyZjntpCD1b7jeciAcMz/2T2a7hueltyOLnaitRA=",
      "url": "_content/MudBlazor.Markdown/code-styles/agate.min.css"
    },
    {
      "hash": "sha256-287TLGyVSc5Rs0UtvVbw2QJCVUdMwQ02q0g715BOd7A=",
      "url": "_content/MudBlazor.Markdown/code-styles/an-old-hope.min.css"
    },
    {
      "hash": "sha256-19BZsrRUfiP7cedxvlQeYJycGmqen0sgSOCgRkBi+IU=",
      "url": "_content/MudBlazor.Markdown/code-styles/androidstudio.min.css"
    },
    {
      "hash": "sha256-E1adQNVyPFLk+wNmkebvctWw6+f0L1/mha8d7U9f/Ro=",
      "url": "_content/MudBlazor.Markdown/code-styles/arduino-light.min.css"
    },
    {
      "hash": "sha256-e6UfWnEtfZ+ZTq/wdHLUn1vhsx3Z8rUET3bCmb8A+Xg=",
      "url": "_content/MudBlazor.Markdown/code-styles/arta.min.css"
    },
    {
      "hash": "sha256-jwxbHYe6fnqz4zk0Y8h3YqhO4WrXtGGERwDNFvliWuI=",
      "url": "_content/MudBlazor.Markdown/code-styles/ascetic.min.css"
    },
    {
      "hash": "sha256-anuTX65gJA36nYIdZy52hWCDuF+SSoLV2fz+m7h0/zc=",
      "url": "_content/MudBlazor.Markdown/code-styles/atom-one-dark-reasonable.min.css"
    },
    {
      "hash": "sha256-RaSazsmkLJwoYkNVKU74LfTbdB75K8e3X6cguGeJ1xQ=",
      "url": "_content/MudBlazor.Markdown/code-styles/atom-one-dark.min.css"
    },
    {
      "hash": "sha256-AwGCb2xPzJ+Nua2otjxyTJSFJMN8o8M9gnPuHnMDtdM=",
      "url": "_content/MudBlazor.Markdown/code-styles/atom-one-light.min.css"
    },
    {
      "hash": "sha256-G4iYMDwzbYvclOlk3uydYoQZQXqR4WfArEW23G/p/FM=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/apathy.min.css"
    },
    {
      "hash": "sha256-Fw1a1j1+x3L01k3RzrG8b0TVoJjsZWcMMCWO65i4t+0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/apprentice.min.css"
    },
    {
      "hash": "sha256-A+uRXM6w6GYkuaAFEokWifimsbJ2RKpj9Fmu1fDSkws=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/ashes.min.css"
    },
    {
      "hash": "sha256-Mw64o5JasQZaLe7Z8nFigUUlA2W0LuNFFsfOGPih0g0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-cave-light.min.css"
    },
    {
      "hash": "sha256-1ZZtP/Yr1BEgP74zDTXg1+IQH3dxwr2V0IWQuEAdnck=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-cave.min.css"
    },
    {
      "hash": "sha256-f9Ttp9Y7oXz5usPW9PWVjL8dUp0enXKPO1PD6o3W4fc=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-dune-light.min.css"
    },
    {
      "hash": "sha256-k+1KmH3gqGhhMznqhOX4VYPMv8Xo0WehqM2aPDN3Qc8=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-dune.min.css"
    },
    {
      "hash": "sha256-HxUhNletuEcDn3CD7JCoFpbx45xCxaSOIVuWPC5nAA4=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-estuary-light.min.css"
    },
    {
      "hash": "sha256-Qncli2FKp2TVxyUbZwW2Dg8Fd0eDB4RMwAWjk5F+TOM=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-estuary.min.css"
    },
    {
      "hash": "sha256-wY23KQEDHtVvyjx9e4XyZ7OWU9uMQYU7o14VImkps70=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-forest-light.min.css"
    },
    {
      "hash": "sha256-q3c1FVVgnJqDlQ16bxkMtZmGXqDWyqO3Ap95fXOoaKg=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-forest.min.css"
    },
    {
      "hash": "sha256-JlXc+cyGQJAQlaAuFp5OtWDn4D7MWXAbmMpiUytlINg=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-heath-light.min.css"
    },
    {
      "hash": "sha256-uSboqdDCUrRQ9n9x0r73UaUXvDN9KgEFVPPAbkeuDLo=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-heath.min.css"
    },
    {
      "hash": "sha256-CaujDMM2XgYhnLPF2i9sGRyDsJIaCTe02ifkeq++P40=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-lakeside-light.min.css"
    },
    {
      "hash": "sha256-su6zp0Txy3LT74dw/hrHpHLeNybVbQ1JUc+Scc2YM0A=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-lakeside.min.css"
    },
    {
      "hash": "sha256-dR0foNs3lYPb6bAQJu+OhTmNN6800F0ISxXVMObT1H8=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-plateau-light.min.css"
    },
    {
      "hash": "sha256-IFHLHZnkmIQGg65xq99tt4t0Fmj/QTpdGtE4r31T+50=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-plateau.min.css"
    },
    {
      "hash": "sha256-Gj9We0Mesq6sp/Zhos58Sn+iit4UwHim5BXKrGBlfLE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-savanna-light.min.css"
    },
    {
      "hash": "sha256-DHKihkfjJ665CDxl7F7O9mph4T2pY7bYiT4qq4QtmHE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-savanna.min.css"
    },
    {
      "hash": "sha256-vNrDHGgIRe7AAt4kqNRDucBETOAjFeCg4R6ehbWXWvU=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-seaside-light.min.css"
    },
    {
      "hash": "sha256-5VAFCqT07/m6BT1j+FyaOTxbVjRKw8nLPNK1GhGiAYU=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-seaside.min.css"
    },
    {
      "hash": "sha256-RG8VppWGmJLgl/4pI/xRcopHT4/aop1BXjg/2XC7/s0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-sulphurpool-light.min.css"
    },
    {
      "hash": "sha256-dAH8ZqW8HYpE+7SsvIZD8o12H1ppDZANw3qWAXvssWc=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atelier-sulphurpool.min.css"
    },
    {
      "hash": "sha256-jAqSAvx6BFlrKEjvp3h564OdBv41VnKju0KzvAM0JSc=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/atlas.min.css"
    },
    {
      "hash": "sha256-78qB8t5EARYRu645ZyA2xhx3hIVkPdhhgqM62gc6VOw=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/bespin.min.css"
    },
    {
      "hash": "sha256-2Z9+36kp3g4LeD0nlBsy38/hqCSgpMY2qiPMB54IHIg=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/black-metal-bathory.min.css"
    },
    {
      "hash": "sha256-/h9W+Ez9EF92dL8Dcd3N43HCkRMMZXr2xCgZGCEc5yA=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/black-metal-burzum.min.css"
    },
    {
      "hash": "sha256-7sbA+ABVNC+Gx5FHe8yTBKjxfBQ/nWTJsZPcNmQS6qY=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/black-metal-dark-funeral.min.css"
    },
    {
      "hash": "sha256-LoJRmuP6VSpjQPOt+QFXmi17cp/Onn/MnXDjJzi32WY=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/black-metal-gorgoroth.min.css"
    },
    {
      "hash": "sha256-g87OXYjnVJgQaTtBgMGyn+oIikJkUKdgR0YteUEfKO0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/black-metal-immortal.min.css"
    },
    {
      "hash": "sha256-a3p0iX0futk4qg/fTaXetSCP4Qol5TrGrWhaMKAk8WM=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/black-metal-khold.min.css"
    },
    {
      "hash": "sha256-1P7GVXcVMJc8RwQlZBE9Pm2RqRWl6ubtxh6hV+jFRSg=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/black-metal-marduk.min.css"
    },
    {
      "hash": "sha256-RcK75cKydSCWwqNN+r9cdS87FMHTlPU4HiKY05+8ikk=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/black-metal-mayhem.min.css"
    },
    {
      "hash": "sha256-eyX1BhExr/k4QnzlLvOmjQF5eCiXX+pH1rAvYicESqg=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/black-metal-nile.min.css"
    },
    {
      "hash": "sha256-naVrYYQwtVO29ZdXxt/TFaDFvwg69Utm5z0jOLecjgc=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/black-metal-venom.min.css"
    },
    {
      "hash": "sha256-V3F/WnvNzgnCErbNxINhVtCEqjxpr+BjH3nXjqcj29k=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/black-metal.min.css"
    },
    {
      "hash": "sha256-H2eUAZrucMadNSlF+9TS/9dFFuPMtXC1Js0crOWqisw=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/brewer.min.css"
    },
    {
      "hash": "sha256-7+UqDsEjL0fj6SrsJoWBrjfgwKCEPRSnqqys9gFhljM=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/bright.min.css"
    },
    {
      "hash": "sha256-C49cOxXflfNhVrlP0LmvjAyWG9YEIuSp2QNAO1MqovI=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/brogrammer.min.css"
    },
    {
      "hash": "sha256-FMam1NFMAXfL+sJ1Luszok4Pg0Tr7qWXriiyTdhyZpc=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/brush-trees-dark.min.css"
    },
    {
      "hash": "sha256-9+ITjL5ifaDo6klIozVK8D/1hl1isYCuOxTlGCUE50c=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/brush-trees.min.css"
    },
    {
      "hash": "sha256-MURwAKhMorovHMsSVoh2IOwutWwEVYK2GZb7LzWKjtw=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/chalk.min.css"
    },
    {
      "hash": "sha256-/XFydCdG/bh/d4EJW+/EHzOLTLiDxzH8eqHdndn3ySs=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/circus.min.css"
    },
    {
      "hash": "sha256-6N//ftFiXlwfarwkiKNTM+06l+aFQ1O5DLAsLuHzRVM=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/classic-dark.min.css"
    },
    {
      "hash": "sha256-5g1pA//PWpfG/hVi/58OqQtV1AZu6+QpkdEko9/RQ7Q=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/classic-light.min.css"
    },
    {
      "hash": "sha256-lT7hf1t95/Alb5UL3dVe3fv6xb9iBjLZbFgUjyWhuBo=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/codeschool.min.css"
    },
    {
      "hash": "sha256-eQZOw1+dSjAfg5tg2zNduet3U8bb2BpgZNSdi9pDnnE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/colors.min.css"
    },
    {
      "hash": "sha256-rITekQRDKAuGSBs4XPJ7bLUhSTgNYpCKaigraXpWdPw=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/cupcake.min.css"
    },
    {
      "hash": "sha256-zfmu4r1Zverqr8vbYOXw6M9gEFcQ7lz0cpJbJliblvE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/cupertino.min.css"
    },
    {
      "hash": "sha256-MmTN1WNoY9xbCoY6zqGBH5DTi195sR3Eg/fNKH8qy3g=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/danqing.min.css"
    },
    {
      "hash": "sha256-Au5sVRAjVaXkTcvHqsdsukAM61LDYrD93SS7UKo48rU=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/darcula.min.css"
    },
    {
      "hash": "sha256-QCTAL6en3vCqjkshvUswyfajZEpfv2ei/RHlhqMMSV4=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/dark-violet.min.css"
    },
    {
      "hash": "sha256-+lh8Wf3G08L5ZmSFoQF64lRlh+FWXnHQYxx1+5wUmFk=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/darkmoss.min.css"
    },
    {
      "hash": "sha256-/d9FxyMHikOWtvDiR3qfap5XkDoM4A+31Q2xiLtdbQE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/darktooth.min.css"
    },
    {
      "hash": "sha256-f3iMtWzS/nKrdYQokn3VMm5hRwhqL/YZWDoTdWmuXiY=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/decaf.min.css"
    },
    {
      "hash": "sha256-fmXjlaHcGYD8O+rkkgIThXNdcCjBzC022QQY7bTx3eQ=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/default-dark.min.css"
    },
    {
      "hash": "sha256-iuIH/INbFeJk2RxvwrIiWjj/998VIMCD4vv5uNWabhE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/default-light.min.css"
    },
    {
      "hash": "sha256-hXrsUe/47BX/4uzK7scCfN6XGZwJeYnbEAwYo8l1sU4=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/dirtysea.min.css"
    },
    {
      "hash": "sha256-BFfgHweS9ML6tDI0PBjIIF/b5luZJI4WQQrSCIDyVio=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/dracula.min.css"
    },
    {
      "hash": "sha256-ygFm3l/kG7vGH+PFZjzXB5Tl9ftWFOpsNaX/PMVmhqs=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/edge-dark.min.css"
    },
    {
      "hash": "sha256-3J1Rwedjm3MVN/qt5t1KLeJQcseUxC4qPwCMHNTVJoM=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/edge-light.min.css"
    },
    {
      "hash": "sha256-cwg29DRvf6FyAvnHscy8mbSsUod85P4fZeDC9fne6Iw=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/eighties.min.css"
    },
    {
      "hash": "sha256-NVZCKJij78tYnxzN7NysGSGGphfO4jlAfiHbDQ7CEu0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/embers.min.css"
    },
    {
      "hash": "sha256-ZUjjPYovC9Fl8V+SZkfFfBRA8acbKT5u8RSXD3rtAJc=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/equilibrium-dark.min.css"
    },
    {
      "hash": "sha256-Uquh6dgjuGKkm2VgBaok7psZzI+FeHaFv530RQ7jBUI=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/equilibrium-gray-dark.min.css"
    },
    {
      "hash": "sha256-mXz3ZaNtSCQ5kyF39dX73WvuayhCbxmmMh6DGMT3Rqc=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/equilibrium-gray-light.min.css"
    },
    {
      "hash": "sha256-jNSRfg9cGLjHI1kHJWHt4zOmkAZcALVJfv5AdNMBSaY=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/equilibrium-light.min.css"
    },
    {
      "hash": "sha256-/0myNt0xcZsC586LK4BMnSQX/TWZuppmyUuat9GDpTA=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/espresso.min.css"
    },
    {
      "hash": "sha256-N2vy4VkkI/9nKpXqasaQKewjWZ6CzFby1cm17XZZGoM=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/eva-dim.min.css"
    },
    {
      "hash": "sha256-5YWeIm2fGEm5+GHxtpxVTFMyseBynujYFSVq34RSnd8=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/eva.min.css"
    },
    {
      "hash": "sha256-KJ4Lw72Gh/mpJpXypvEyNLOQx/sLZhaPvkcG4xwXNEs=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/flat.min.css"
    },
    {
      "hash": "sha256-kNoJ7hMRlZ1PjW+yO1PuqVG17gaecIHCze/KmfXfTaQ=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/framer.min.css"
    },
    {
      "hash": "sha256-c6blb+ra7CBzyt7BYp+deZDRRVX1cJjrTCz+Pjun0WM=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/fruit-soda.min.css"
    },
    {
      "hash": "sha256-8reKF1O7GvGK5qqUJlnk2yAxHfntV5z+FqY8KX5+Ou0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/gigavolt.min.css"
    },
    {
      "hash": "sha256-1VbRmDHqI5H+k8n1ZACMxZ5SEIkXb/h03Z6hC0YaAPw=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/github.min.css"
    },
    {
      "hash": "sha256-wQnKxXRePVC8t8hdSXm680R9BWTQdI3cr8IlOm5KNPo=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/google-dark.min.css"
    },
    {
      "hash": "sha256-7xuCjdKsVdynkyYvAQa6FjkvZdlF0bXlxQrdhlErtjE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/google-light.min.css"
    },
    {
      "hash": "sha256-YWgT2ZEUHrjQO/S76e1t5SDnL81I938/RiALUXXaHvw=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/grayscale-dark.min.css"
    },
    {
      "hash": "sha256-x2HdXGXUGYhYmmenNzFF+op+XpEwbBSezTuy7kxm8AE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/grayscale-light.min.css"
    },
    {
      "hash": "sha256-zObpjU3dvV7m6+Hzg2lv5jzn4mA9Ertp98lTXQ0QfH0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/green-screen.min.css"
    },
    {
      "hash": "sha256-wr2xbgaDb93H6NwwqGjRJHCfRe5tXVmDFyT5SqDr7zk=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/gruvbox-dark-hard.min.css"
    },
    {
      "hash": "sha256-FtscetUbLN/3OIKBfIt/i01urLY4/z1rkm23/Z3GXEE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/gruvbox-dark-medium.min.css"
    },
    {
      "hash": "sha256-84iSdN6xok4btD7OeTKJmmOeTYujbed2xP2NeelV+s0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/gruvbox-dark-pale.min.css"
    },
    {
      "hash": "sha256-nM+pWYibYuhZwieAdBsiCh61KPD+UdCpdEqvYsXfsEk=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/gruvbox-dark-soft.min.css"
    },
    {
      "hash": "sha256-utn9yCbv4WETd73WkufojdEaXBYLPqonJs2JBdMCuBA=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/gruvbox-light-hard.min.css"
    },
    {
      "hash": "sha256-vuYqrWDbJcrCFcgCfVxw7SKAeV89oMnUH2kvnWPby7w=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/gruvbox-light-medium.min.css"
    },
    {
      "hash": "sha256-fv58EK8i+Gh83K6s7P6vYxKqUM36Bipmi/4UeGr+WFg=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/gruvbox-light-soft.min.css"
    },
    {
      "hash": "sha256-Utb1+Q18ECq38SsyLy6/iq4gCbjx82Ji1isJhGxAcbg=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/hardcore.min.css"
    },
    {
      "hash": "sha256-ZLLEy9Fwj3gxmo36u7Un52Ok7l+HZiY5xe5zfdWhmg0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/harmonic16-dark.min.css"
    },
    {
      "hash": "sha256-ddp2YjX5xRiycJQLO+O85zdHAd4Z5rsqR2KWg3p+LiE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/harmonic16-light.min.css"
    },
    {
      "hash": "sha256-Kt6fFH8i4DSQK1cCR/9pkosNmXEZt1quUfVT9qLjLjY=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/heetch-dark.min.css"
    },
    {
      "hash": "sha256-Z0aYndAXE4Mk3dZ8vSFkOkpWtYxmBcF0l6MhjG13Mr8=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/heetch-light.min.css"
    },
    {
      "hash": "sha256-BfQJ33g3iqTL6W5tMjBs/eraNtsFiB2WcR/TN4uSOOU=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/helios.min.css"
    },
    {
      "hash": "sha256-rd/UNfYJ1XPdNh6mVpbj5t4bu3T/ak7RaBWDirFFQIA=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/hopscotch.min.css"
    },
    {
      "hash": "sha256-2weKQ48Zuyaa1HCdT6hktfbXFKaC5Wn60GyYPypmAhE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/horizon-dark.min.css"
    },
    {
      "hash": "sha256-Wo/yXPoGPY/K6uS8wXF4ma0mWEDYBoEBEMQwMgB7od0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/horizon-light.min.css"
    },
    {
      "hash": "sha256-fex3PTXR4EDkPythHiz28vXSwMK9AOUcjjDKWathSsU=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/humanoid-dark.min.css"
    },
    {
      "hash": "sha256-h8HAuVyTHgma7ZgTfObYgtr9FHbLZwvNiv6Gq/5Nj5E=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/humanoid-light.min.css"
    },
    {
      "hash": "sha256-XdgfCQIMirnSRSjXWv22YohqI3auV7KPxvikM/39REA=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/ia-dark.min.css"
    },
    {
      "hash": "sha256-2nl4pPPpVO2n6ZaaJIh9+dfIsISDctNhDaOtTXdpQ7g=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/ia-light.min.css"
    },
    {
      "hash": "sha256-wUeMY/mZ5fAZ5DFKuEBNvceP/91V9RUH2S/bOmFKGbs=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/icy-dark.min.css"
    },
    {
      "hash": "sha256-pglqDTR7VsIjeyGGEO75hZD1rO+7p3dwJ3WWWO0iV70=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/ir-black.min.css"
    },
    {
      "hash": "sha256-odGwhdl/8FnW0M8KQeKc3S7xElr+tPWBkg5VTyO0nX0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/isotope.min.css"
    },
    {
      "hash": "sha256-qSerOtFNj9QW9tXHjPKjK30CMQG817hB0xMZTxj6k+c=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/kimber.min.css"
    },
    {
      "hash": "sha256-kH4JWk1kwm1K2cPBQd0Zm7A+25ov/FZJBu3hyborSjU=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/london-tube.min.css"
    },
    {
      "hash": "sha256-Spt17+ja7MDHJG2WlS32cxgC3Y7YuiNy9Ei26kJOMdw=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/macintosh.min.css"
    },
    {
      "hash": "sha256-l0vZjVtCqWefrwYU79aQYxcIgDpF6S2GPuwyseKFjww=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/marrakesh.min.css"
    },
    {
      "hash": "sha256-U42VKGyNCDY4Sy/Z4kxjHWGtVLkxMnuCWQZpoGMsu3Q=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/materia.min.css"
    },
    {
      "hash": "sha256-3OvR2Xwn07p/BYqntSP5i7QcpeoREoLs3iNGjQ28xgc=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/material-darker.min.css"
    },
    {
      "hash": "sha256-uWtFkjyV0nImFr+xLLDIom3AzmBOQu0Kb176KlhqGh4=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/material-lighter.min.css"
    },
    {
      "hash": "sha256-0MbdamSOylLTR+22fixb63vMTQIJWuecoz7NXbay9i4=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/material-palenight.min.css"
    },
    {
      "hash": "sha256-3TbUBxUhGCleFa12TAfR65uil00Os0aioVXOYr40Aqw=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/material-vivid.min.css"
    },
    {
      "hash": "sha256-7kI3/3QRB4Auze9UgaDFU8MLXaF6/W5ojczUzkFF2nI=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/material.min.css"
    },
    {
      "hash": "sha256-7NeDuaaKeeSd0YgxeCQlOAgoMLJkex5xyJ0a/9v0ae8=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/mellow-purple.min.css"
    },
    {
      "hash": "sha256-xzufRgefmi16zLGRJOf8QC+CVkmey2FCWATqYqtowPM=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/mexico-light.min.css"
    },
    {
      "hash": "sha256-zcQdzQHeLT0xlxnYLilFZhE2owt0s/tarIH+18A5eqo=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/mocha.min.css"
    },
    {
      "hash": "sha256-iF1y+S92ljyNChfd06epnW3kkZcVf+0x0uDDArmpRMA=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/monokai.min.css"
    },
    {
      "hash": "sha256-xCclZZvzuuL4In/22g8tMPMpyRB0pxemM/aEQ4zVStI=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/nebula.min.css"
    },
    {
      "hash": "sha256-Onaq4AbhDhRR9JsfxYLFJhqA+VZS17rFLMpLnJ4cOPY=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/nord.min.css"
    },
    {
      "hash": "sha256-jnpErNt5bLwcr7PDxt02gwEKXE1dmXMId5KzdTKKEYM=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/nova.min.css"
    },
    {
      "hash": "sha256-A8wfmhZqeZ3fynomImurgzaFuSh3k6EP7T9IUZSgY1Y=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/ocean.min.css"
    },
    {
      "hash": "sha256-/1HkHCfNzPS/mMHUHRakQlvC0EMPYOiljyjxLbDBhEE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/oceanicnext.min.css"
    },
    {
      "hash": "sha256-DpHDtzQ+y+yDf5HwOgz6Zl5PjLaedQuXL1zWqIqE3KA=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/one-light.min.css"
    },
    {
      "hash": "sha256-7lSCiKUbDPEPWOmdkQ12ySXYbNvpvynXhHPD20KpyLo=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/onedark.min.css"
    },
    {
      "hash": "sha256-LnXaGBJG3JUTtq88EQ8MErtHquvQz965x0e8xGbQgqI=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/outrun-dark.min.css"
    },
    {
      "hash": "sha256-7tF3X+Pvpp/cgqhlh0ujmQZt8HDrikAc+G8WKJWskXQ=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/papercolor-dark.min.css"
    },
    {
      "hash": "sha256-EGK5y5TkVhTEUNhxbGRFSm84gYrX/3IhXP4dwMV+bGs=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/papercolor-light.min.css"
    },
    {
      "hash": "sha256-aSP+73GY0o/gT87GBjk7B1FzKmHX58AVCWIp1mPx9aA=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/paraiso.min.css"
    },
    {
      "hash": "sha256-q7TGB14LiohL/4JRS/uL6x5P1ZMF+zTor/X2gqlRyRQ=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/pasque.min.css"
    },
    {
      "hash": "sha256-TbOZ7kBH9W/d4/6q4mwdLy5HhmOPDU4kMhwZ4MuGzoA=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/phd.min.css"
    },
    {
      "hash": "sha256-telwwDovlvhG1HaUuMefrhpAKRpqNrdSYxlF6wiTABk=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/pico.min.css"
    },
    {
      "hash": "sha256-ZLIVvaYTsnolJWig/xO9KkM3mGkSOl5/GNvVHpRCFCE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/pop.min.css"
    },
    {
      "hash": "sha256-1OVrG6zxWulGq5wKLcqYkFO9Ln4UHmvsKLNYTtgzBd8=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/porple.min.css"
    },
    {
      "hash": "sha256-iMIxOKUurFXXD3PN93S3NcRi0rbvr4JK7mrJM/nrJN8=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/qualia.min.css"
    },
    {
      "hash": "sha256-4k9SW5qWvMwenpdFWGOpNBA69qvelBkzHdtRwi+zJ1k=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/railscasts.min.css"
    },
    {
      "hash": "sha256-3ebMNgw4sJAXLXXsGPHo1UXvr1uIoPdTZAR/1+dThXs=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/rebecca.min.css"
    },
    {
      "hash": "sha256-f3ciHP6zYCO1PS5zHLYnqEOrMXE6Bcg0yutkYFtoYbI=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/ros-pine-dawn.min.css"
    },
    {
      "hash": "sha256-PqLYSwePItm5Sa05/eN3CD+sKGbrJwxZ9RVKlJpP1RE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/ros-pine-moon.min.css"
    },
    {
      "hash": "sha256-RnAdEfocpXqI8LK+WQHkAB3T3S/rzLWlHoADR4MKzRM=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/ros-pine.min.css"
    },
    {
      "hash": "sha256-14wtk9+PaldBeA34Gs93Wiwgb+9yWEPQ0hcyAEn/dFE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/sagelight.min.css"
    },
    {
      "hash": "sha256-6SQe7Qs45ZQkurhWf13rmgzGVDuXBdOdbLwUXKxVe9A=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/sandcastle.min.css"
    },
    {
      "hash": "sha256-ORkzELTnkkG6lmXkjCMtEEnMLf7OI/ayco6jNA14m8o=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/seti-ui.min.css"
    },
    {
      "hash": "sha256-lbpROjz8aGT9btAWDckSujE4BJTUcEJ8/DyK//981Xg=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/shapeshifter.min.css"
    },
    {
      "hash": "sha256-W8ruZN3ha7mhRDXjZ/Fb/gg+Ln2WfCvyHVv+KR+raMo=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/silk-dark.min.css"
    },
    {
      "hash": "sha256-kMkwc7R1u74/y4ojUQPVsD7ANKy+fqZXePOpz//rsMM=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/silk-light.min.css"
    },
    {
      "hash": "sha256-ZxZ9RLOgcl7daq2wu5PCsQYMlUrrvC+vMDUtA6iDIwY=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/snazzy.min.css"
    },
    {
      "hash": "sha256-E6Uk2befVHxScnVFPpqfe4P0IuNOINNumvz2ZC9K35k=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/solar-flare-light.min.css"
    },
    {
      "hash": "sha256-A53V5wwEYzAuSyA7E5vdakCXXlQ1oarS9pkL2Ib+JrI=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/solar-flare.min.css"
    },
    {
      "hash": "sha256-JZpNmQZYLpMNXt+vTHmxaPydO3VgPRw/sJdORaFA+0Y=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/solarized-dark.min.css"
    },
    {
      "hash": "sha256-RjAcewr70LkBBni/iPjmkRrzXamk6cg4qw6ApaxoFO8=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/solarized-light.min.css"
    },
    {
      "hash": "sha256-5STppQDpl8uNqy/f3g0pUYHDW0kO3+PAQBl4ZQMOGC8=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/spacemacs.min.css"
    },
    {
      "hash": "sha256-86BcT3Z4K/NCuT5G1tcm6aGpLrJrGVPRL1iikFudhJ4=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/summercamp.min.css"
    },
    {
      "hash": "sha256-1e02zPRlvu7huuELpZ36lVK/lEupHWq+ucAYtuae/XY=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/summerfruit-dark.min.css"
    },
    {
      "hash": "sha256-q9Xh/KdHkydiaSvFi4nnEi2vQHiMVVqSGL7I+USebqQ=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/summerfruit-light.min.css"
    },
    {
      "hash": "sha256-ZGVq2q2FBPMNIYIpJOHTBux1omPWy55DvbwlOguG+TE=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/synth-midnight-terminal-dark.min.css"
    },
    {
      "hash": "sha256-gkF0WvskrKxOx6n9MKG/wmziSeyJUviGAicTf1Ad/rI=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/synth-midnight-terminal-light.min.css"
    },
    {
      "hash": "sha256-7LYtoAjKWDqnevXxKehhFWY6IQcd9K0+ZIa7uL9fbZs=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/t3024.min.css"
    },
    {
      "hash": "sha256-0BYj3LLzIsdnKO7Wh4Qyp0oeJk3f440TUWYvImhpj5M=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/tango.min.css"
    },
    {
      "hash": "sha256-CTfJpJWyWl/2HTZ2vFRPhKeuonKSCAuF3p65Pu66GhI=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/tender.min.css"
    },
    {
      "hash": "sha256-Hy13s5nLD/KHvQKX5faSBlj0lc97N9PDY2dXpb9MK1Q=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/tomorrow-night.min.css"
    },
    {
      "hash": "sha256-93W+yQ8jcEoQhil1XmunMbaAY9w2GoCLpaooLU9O094=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/tomorrow.min.css"
    },
    {
      "hash": "sha256-MEpyUyNVu7LC+5LpAJ0K9cDtYwEe3oLOXs7rzx2jd7Q=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/twilight.min.css"
    },
    {
      "hash": "sha256-tQaNdPkpPZ94LNGOTGee4UzxEwwzfl7RgrMTS8G9VEU=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/unikitty-dark.min.css"
    },
    {
      "hash": "sha256-MVMlns16Gmwqn+xvV3895UBzoSLdW+2y1drCBtosp+o=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/unikitty-light.min.css"
    },
    {
      "hash": "sha256-tEntC3ESMEUhMEs2ibS7cMsgvOYW7rVLZSXoAfHjQI0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/vulcan.min.css"
    },
    {
      "hash": "sha256-9TgNFBXnyJLTqatxSFJ9qIKvQz/l1sNXPXr8Ku3Trxo=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/windows-10-light.min.css"
    },
    {
      "hash": "sha256-MOkxsXL3jR0MKZ7Cofwlht0ygBaflIuVK6e1tflPqq4=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/windows-10.min.css"
    },
    {
      "hash": "sha256-tSP3neLGcGa+/yUieW4FhArXIzHp4cLTI8Vcnx4uwa4=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/windows-95-light.min.css"
    },
    {
      "hash": "sha256-vSv9XgoVhCbTof034YD+8G5PfV/51sK8D6mXmyaQQ5g=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/windows-95.min.css"
    },
    {
      "hash": "sha256-eKFuh3YLouEe6aK2MUe2ViF6AsJ0KsgAjRuyiIQ6/Q4=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/windows-high-contrast-light.min.css"
    },
    {
      "hash": "sha256-DaS8l7mioZZyzzKcQ2GymrBvwm1Ptn7TWDRdipoD4WI=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/windows-high-contrast.min.css"
    },
    {
      "hash": "sha256-vKnztAuD9h4WaRG6wOBiFyxaqj5P0fozkQXcIWegs+g=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/windows-nt-light.min.css"
    },
    {
      "hash": "sha256-u8vDCT9A1aQ5lBtGwOr8vFfTcGgdzdNai2mEhkfs7Cc=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/windows-nt.min.css"
    },
    {
      "hash": "sha256-2uonIv/F9CE1Vn1Rllzvi7FycNsxQqt0s0U21u7eUs0=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/woodland.min.css"
    },
    {
      "hash": "sha256-0BEnWIhexfW9BLeHegDjoICy2+xCNdsUU9OGJyTL4Uk=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/xcode-dusk.min.css"
    },
    {
      "hash": "sha256-RNDfxA5ReG7qBsZx9H9e1UYkTJ260gAvpdf6bLuHZqo=",
      "url": "_content/MudBlazor.Markdown/code-styles/base16/zenburn.min.css"
    },
    {
      "hash": "sha256-ZXt33FMK3WE/PtiuBgc5oi2ZRt8WPRnNzetU6MHDRZs=",
      "url": "_content/MudBlazor.Markdown/code-styles/brown-paper.min.css"
    },
    {
      "hash": "sha256-tH3C43sYUXxAxb2NpOqrUKxbNV5XOf9FbH2VXid/0sI=",
      "url": "_content/MudBlazor.Markdown/code-styles/brown-papersq.png"
    },
    {
      "hash": "sha256-5DaS/upri9wp3UgasAAgnBGojqJVXgzDZQz6/1f7fSc=",
      "url": "_content/MudBlazor.Markdown/code-styles/codepen-embed.min.css"
    },
    {
      "hash": "sha256-pxLf1um6e3RuXugKvCDxEpCKigct5ilWXC7MEdFTdag=",
      "url": "_content/MudBlazor.Markdown/code-styles/color-brewer.min.css"
    },
    {
      "hash": "sha256-2iq72tBUoiVP3SkCBhrnlWtmtuU8ZLK/04GoMTZm4/E=",
      "url": "_content/MudBlazor.Markdown/code-styles/dark.min.css"
    },
    {
      "hash": "sha256-qX3ZbJxobZcyM2WasE3I1Lo9VJkvsKdtHpI5nmYBr5k=",
      "url": "_content/MudBlazor.Markdown/code-styles/default.min.css"
    },
    {
      "hash": "sha256-313nruji+iYPSss7+Ex48lVUzbqhYSGkRV4HdhRvoMU=",
      "url": "_content/MudBlazor.Markdown/code-styles/devibeans.min.css"
    },
    {
      "hash": "sha256-UpFPmYDUg0A2UDiQG5hc6x/M52vP2b0oGIpy/eYmd/I=",
      "url": "_content/MudBlazor.Markdown/code-styles/docco.min.css"
    },
    {
      "hash": "sha256-rcc+O6TJK1sxB1CfQSfSFeIGf+I394P9AbwwqpEEomg=",
      "url": "_content/MudBlazor.Markdown/code-styles/far.min.css"
    },
    {
      "hash": "sha256-ry0KFt6CkBZ+fyHAmLPOeBrJ8FFXT88BHbmPueIrlVg=",
      "url": "_content/MudBlazor.Markdown/code-styles/foundation.min.css"
    },
    {
      "hash": "sha256-QaJ88oR/OfUB2Y0wDSiXvEZ91LxIgCetAlm/QX2G49U=",
      "url": "_content/MudBlazor.Markdown/code-styles/github-dark-dimmed.min.css"
    },
    {
      "hash": "sha256-xrdGkr9dQPjK2EvSCq/0hq+JOmD/cVc6p4Tj1os7pTY=",
      "url": "_content/MudBlazor.Markdown/code-styles/github-dark.min.css"
    },
    {
      "hash": "sha256-tzdudDkDBx5/RzG3omGGxxMj9U0EFLGj2pxg/UcjlGg=",
      "url": "_content/MudBlazor.Markdown/code-styles/github.min.css"
    },
    {
      "hash": "sha256-YgoZzmigqhV8TZpYs4dzAGZubGntQMcw8gJrd0vxbH4=",
      "url": "_content/MudBlazor.Markdown/code-styles/gml.min.css"
    },
    {
      "hash": "sha256-4Gf3/patQTpMEzqsuH7nUYso5tW6NX4e4zvZ4LRRNbU=",
      "url": "_content/MudBlazor.Markdown/code-styles/googlecode.min.css"
    },
    {
      "hash": "sha256-qB2QCrKtDxks5HXJqPPwA+8O/ey402vkCR1gltLJ3qc=",
      "url": "_content/MudBlazor.Markdown/code-styles/gradient-dark.min.css"
    },
    {
      "hash": "sha256-Jsnfiq3Sx4QWk7pX7Yd+mRWEmMvYbMm4wSSLU5Q4u6Q=",
      "url": "_content/MudBlazor.Markdown/code-styles/gradient-light.min.css"
    },
    {
      "hash": "sha256-pEqUpSwMYz5qHp834XxSwqrblo1s8F40ghh0+Zb9sCY=",
      "url": "_content/MudBlazor.Markdown/code-styles/grayscale.min.css"
    },
    {
      "hash": "sha256-KYsFRrAGGhpEnBmUaP4PSt97qXl0eW6J6KD5CnBaQGI=",
      "url": "_content/MudBlazor.Markdown/code-styles/hybrid.min.css"
    },
    {
      "hash": "sha256-6dettxNgaM63T5D0y8syUoKCJJCFejh/d6TYRj64MLQ=",
      "url": "_content/MudBlazor.Markdown/code-styles/idea.min.css"
    },
    {
      "hash": "sha256-4xA5qVAlS7IAot9aHzxZSn8mpxQkXilLKDxsG8rWy4I=",
      "url": "_content/MudBlazor.Markdown/code-styles/ir-black.min.css"
    },
    {
      "hash": "sha256-YTyv+q2bceFEOZJ1eRHauVGjePaKqt6dZXl3/boimU4=",
      "url": "_content/MudBlazor.Markdown/code-styles/isbl-editor-dark.min.css"
    },
    {
      "hash": "sha256-AfR5/UTTOrfsopQngNCQu/9RRf8x+Sc+lSHHPWtuaFQ=",
      "url": "_content/MudBlazor.Markdown/code-styles/isbl-editor-light.min.css"
    },
    {
      "hash": "sha256-+Uu81GrUkTeXHrdacHRS1x+KiDyvQlec+ZWgBijNVZI=",
      "url": "_content/MudBlazor.Markdown/code-styles/kimbie-dark.min.css"
    },
    {
      "hash": "sha256-UhjgaenxWIUed3qfHY+yxBqa55bxco2Le9/fqnSByaM=",
      "url": "_content/MudBlazor.Markdown/code-styles/kimbie-light.min.css"
    },
    {
      "hash": "sha256-E4kEdAPJN0f+PnM0PifL3cBw9LkDXHY6pPkyOCmPWBk=",
      "url": "_content/MudBlazor.Markdown/code-styles/lightfair.min.css"
    },
    {
      "hash": "sha256-eBy/x6Sg0imFJ/23hS/84YsjUXx35i4G/a4gwlaUIz0=",
      "url": "_content/MudBlazor.Markdown/code-styles/lioshi.min.css"
    },
    {
      "hash": "sha256-ZUIOIP4jUY9rufCUsid1RFRoAEujIRPzcPgr7Sch9TY=",
      "url": "_content/MudBlazor.Markdown/code-styles/magula.min.css"
    },
    {
      "hash": "sha256-E6OVi2P5M5tujOUlQs7H3sDwLGZ4WzQOTsITWaQUiXY=",
      "url": "_content/MudBlazor.Markdown/code-styles/mono-blue.min.css"
    },
    {
      "hash": "sha256-TcqLHZrDN9egKCnxY5GJoFqyEBb6pnUE0zikTrGGBVA=",
      "url": "_content/MudBlazor.Markdown/code-styles/monokai-sublime.min.css"
    },
    {
      "hash": "sha256-qwVuy4wkbUI7SW14OTM/UDctKRV3QhTDujwocfcyczw=",
      "url": "_content/MudBlazor.Markdown/code-styles/monokai.min.css"
    },
    {
      "hash": "sha256-CXbHDaGhdy37dxko3Y1KXcPJx5OzJB7PLj1Dos9//6w=",
      "url": "_content/MudBlazor.Markdown/code-styles/night-owl.min.css"
    },
    {
      "hash": "sha256-8r5AtaFAhuRuKR8HEy8C1AuYV2UPVJL7CD1J4cSKlqY=",
      "url": "_content/MudBlazor.Markdown/code-styles/nnfx-dark.min.css"
    },
    {
      "hash": "sha256-YMZGMwFVf0SZ749d8Ua9PiPZwntEuLEmnf04HaM7ejQ=",
      "url": "_content/MudBlazor.Markdown/code-styles/nnfx-light.min.css"
    },
    {
      "hash": "sha256-X2w66oZc63+XLLmh9Z/QzRfRkLaefjk/t2BO37a4scU=",
      "url": "_content/MudBlazor.Markdown/code-styles/nord.min.css"
    },
    {
      "hash": "sha256-r6wLqp+EDBvkVq3PVdLoVJk/oBaXSuDDAcSOMNWQ/lI=",
      "url": "_content/MudBlazor.Markdown/code-styles/obsidian.min.css"
    },
    {
      "hash": "sha256-52sGPqi6ShMIcenIeZnV//1vlNxlqfX2qGSZX7MaKpU=",
      "url": "_content/MudBlazor.Markdown/code-styles/paraiso-dark.min.css"
    },
    {
      "hash": "sha256-foX2dn/7xBhopfrbQZnv0EJ+DBgTpCZQ5iGbpC0y45s=",
      "url": "_content/MudBlazor.Markdown/code-styles/paraiso-light.min.css"
    },
    {
      "hash": "sha256-XAzAwx9Jv55QdLPCiHtz+Do+DNEnI5uzKI2F+JQ8lqE=",
      "url": "_content/MudBlazor.Markdown/code-styles/pojoaque.jpg"
    },
    {
      "hash": "sha256-dPKeq6onS+q0OUsoZhuTE1yH7LbqVclFhbNqA9gcQ+M=",
      "url": "_content/MudBlazor.Markdown/code-styles/pojoaque.min.css"
    },
    {
      "hash": "sha256-96P/CAVHcSyhlOVb0FWV/l73z2uLhGkP91g8Fm1KD+k=",
      "url": "_content/MudBlazor.Markdown/code-styles/purebasic.min.css"
    },
    {
      "hash": "sha256-c4dghbvQ8sz5vaB5beAyfZw6xCUd9UEPqzvx02cBHWg=",
      "url": "_content/MudBlazor.Markdown/code-styles/qtcreator-dark.min.css"
    },
    {
      "hash": "sha256-K+KRVz5I/q0yPTHahuXqj+moc3qSTlor9HkHVgsiemU=",
      "url": "_content/MudBlazor.Markdown/code-styles/qtcreator-light.min.css"
    },
    {
      "hash": "sha256-/f9sk5JG49zgCdC00QxjZY1ZxxaYh5IvJZ97M3/m4q8=",
      "url": "_content/MudBlazor.Markdown/code-styles/rainbow.min.css"
    },
    {
      "hash": "sha256-XqS+ffPvaLQSCgcH1s+AgCM5vnPMKRn2z7m/mB8KhEs=",
      "url": "_content/MudBlazor.Markdown/code-styles/routeros.min.css"
    },
    {
      "hash": "sha256-1T7Tqtp5jQ/qAZP0k3RXAv5GvlpnySvT7yOViObvtmk=",
      "url": "_content/MudBlazor.Markdown/code-styles/school-book.min.css"
    },
    {
      "hash": "sha256-xHVZEAfgt/VoXg6kW8QCCJyDinSL3Hsbwh04GhKRBN4=",
      "url": "_content/MudBlazor.Markdown/code-styles/shades-of-purple.min.css"
    },
    {
      "hash": "sha256-Vvuu5jcCC4Da+QNE93UCAsTEYj5Fg99g2pDIstjBzkw=",
      "url": "_content/MudBlazor.Markdown/code-styles/srcery.min.css"
    },
    {
      "hash": "sha256-Dn9l6QdGV6dAbtFI2h36yYWBuuqa7qJbHPMbsDan7FM=",
      "url": "_content/MudBlazor.Markdown/code-styles/stackoverflow-dark.min.css"
    },
    {
      "hash": "sha256-bUT5oQIYXbPSt8YZkeBp5zsRBkxS531sciEzVe7HEDg=",
      "url": "_content/MudBlazor.Markdown/code-styles/stackoverflow-light.min.css"
    },
    {
      "hash": "sha256-q4hr4gPhkBda+Fh+qHctXpPSsDJ/W1Kf/zX+mB1uZ1M=",
      "url": "_content/MudBlazor.Markdown/code-styles/sunburst.min.css"
    },
    {
      "hash": "sha256-uF804OXf5+b/uqHSpbbitzavN4/hq4ne5vM7Q2U8+bM=",
      "url": "_content/MudBlazor.Markdown/code-styles/tomorrow-night-blue.min.css"
    },
    {
      "hash": "sha256-TZwJ0OZDuyH50yz1TzlWSsXRSH0X3EqCgADYX/UiIXw=",
      "url": "_content/MudBlazor.Markdown/code-styles/tomorrow-night-bright.min.css"
    },
    {
      "hash": "sha256-jscYoLippjCa/yij2hNRh/ECLy1iOdcZ4AxN+WYIi2A=",
      "url": "_content/MudBlazor.Markdown/code-styles/vs.min.css"
    },
    {
      "hash": "sha256-4Q3MSZAjLhL3+EWQhOP+G3pMSU1PhUN8FMPIsbpDdD4=",
      "url": "_content/MudBlazor.Markdown/code-styles/vs2015.min.css"
    },
    {
      "hash": "sha256-smms6IAXCZ0lYzH/wrzufjsC66L0CyqCeznzxTPEe88=",
      "url": "_content/MudBlazor.Markdown/code-styles/xcode.min.css"
    },
    {
      "hash": "sha256-Y0gzJMjLM5j5B0XbMWbFazlL4GVtVs/wXAZWkEk4lEA=",
      "url": "_content/MudBlazor.Markdown/code-styles/xt256.min.css"
    },
    {
      "hash": "sha256-Px+Kf9fUfqy09TIwhZm/gXX6XXdAVsyn7icweq8xzPo=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_AMS-Regular.woff"
    },
    {
      "hash": "sha256-CgQU0aAO509v5n/ZbWyK+hsFEDz/AYn4z1oE1R7nzpw=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Calligraphic-Bold.woff"
    },
    {
      "hash": "sha256-vTRKvtF6XUyHNCPcyjrEjs4Zhsm46Cjla/hIwBF4aVM=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Calligraphic-Regular.woff"
    },
    {
      "hash": "sha256-5Ro5Ouv0qFKaZDZ4uc97Z354FXqoW+hH7Yzq9RksOBc=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Fraktur-Bold.woff"
    },
    {
      "hash": "sha256-pfxt6PlF6GJI1HyQpZWUrvD/0+waAsTj/EG2EngbIGQ=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Fraktur-Regular.woff"
    },
    {
      "hash": "sha256-FQNMp1ppS+eDyhNFc7lpie/Fs0oAKpUMFj2zBXWYU6k=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Main-Bold.woff"
    },
    {
      "hash": "sha256-Xn1F72JlUdppXbvSrp4LERjYGvoch3tgHwaa5fyg5u4=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Main-Italic.woff"
    },
    {
      "hash": "sha256-8ASYHaV6jOvJzICwmBuB7kJDUUkpFXrxoF3mnN59/OI=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Main-Regular.woff"
    },
    {
      "hash": "sha256-7WjDnv4jPADtKhfrgtlvXCE3/H3mjQaR27rXFIwOXkw=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Math-BoldItalic.woff"
    },
    {
      "hash": "sha256-W3s5HOowgLWWQQ0aGP2e5F9UCNYBOCm4micCz4PPcyw=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Math-Italic.woff"
    },
    {
      "hash": "sha256-tNa7MtdIit2M6HAfCZZdT6D95DiqUf9wfgE9h4cWXHM=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Math-Regular.woff"
    },
    {
      "hash": "sha256-oHgUfid4rizFfOYXnDXkxwTg/2N3P8JqFXjmF0O1b8A=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_SansSerif-Bold.woff"
    },
    {
      "hash": "sha256-ogdcBvkiAMEQVPFgsfR3NPzpMOvWHeG6x+QNOoO3Y1k=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_SansSerif-Italic.woff"
    },
    {
      "hash": "sha256-21mIY1KqerTD/9WuwHuOKAy0SNTnMkgnPM+4yWvcOL0=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_SansSerif-Regular.woff"
    },
    {
      "hash": "sha256-caNiuZjQyBZBPFV6BurSbX9ud11atxObYiwrFxnUqqc=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Script-Regular.woff"
    },
    {
      "hash": "sha256-H/GgxLxM9AL16fRmozuWdcaBcGzKlJlOdR4E0W7RohA=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Size1-Regular.woff"
    },
    {
      "hash": "sha256-KAZtLvB2KHV+06rF1IhTmDcoNqdQLYws3hhaCX/+LuI=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Size2-Regular.woff"
    },
    {
      "hash": "sha256-EoCYyva/+fK0IIvu+o5Df1ec8dc2jA92+Rz7udATy5Q=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Size3-Regular.woff"
    },
    {
      "hash": "sha256-mzjbo3VQSSqkkXaDNylNo9txSS4OcMdGxKXuAVy5e1Y=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Size4-Regular.woff"
    },
    {
      "hash": "sha256-JaLMMLxlZOg1xcwViFkI9GZ3QyQbE6PAxFgp37BXlCE=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Typewriter-Regular.woff"
    },
    {
      "hash": "sha256-L75Su8/sA37mA6JCA4phNcucx6Bix6u5ou5Wh5D7O2k=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Vector-Bold.woff"
    },
    {
      "hash": "sha256-fvHgRnSeJjtYbAApw1LFBLtBL9b9+KpUMf5pG+vrfDI=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Vector-Regular.woff"
    },
    {
      "hash": "sha256-+TDEGE1k3l0k3GxLMCFn08uDEFBnRrCbnB+H58DjCug=",
      "url": "_content/MudBlazor.Markdown/output/chtml/fonts/woff-v2/MathJax_Zero.woff"
    },
    {
      "hash": "sha256-rBB/VWSWCtjXAbkbYUaRz+Nj7BYmb0plepbiHX9QpFY=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-MdGoP3qrZ8UopW79bUDKgQbLV8ZNFJ58gGGUasEobjM=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-ZZeiUTINVdcrhmqtkgRhI/g0YXWfahOZ2XUmxIDBsBc=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-l1wTMTENyM79ld4SDLq1FMaVInry9paOdQP7C16wl1E=",
      "url": "_framework/GiscusBlazor.pcuv0mq90t.wasm"
    },
    {
      "hash": "sha256-iLHQQd1K5dAo8IOhVWL2aAMt6lT23PTNXcWQhao02uI=",
      "url": "_framework/Markdig.wiadr0c2am.wasm"
    },
    {
      "hash": "sha256-vFTL6yQJ6iuydXJkdg8j6zSRroQ5QStlsEMvbACF924=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.cib096z7rw.wasm"
    },
    {
      "hash": "sha256-0WwVpiweYrHdpPIrqy1k6yx2UtSNmawpDb9Nkv1XnYQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.72mifddv5o.wasm"
    },
    {
      "hash": "sha256-8Xe51dfXkmgreI/FWV+bndfV/OMgYbsXWnhUOgTnErk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.h06an5551r.wasm"
    },
    {
      "hash": "sha256-h6ZSSqEndfV2YXcja4iQEuZ2rLKD0ZAythkM8HIFdIQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.3t3dmrnfil.wasm"
    },
    {
      "hash": "sha256-EKsq+iS6YsSWpMgveJWFtxeVCnIl6aHnA6eR9afOC6E=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.wcqyr45rut.wasm"
    },
    {
      "hash": "sha256-IKYgK7uy/R7+wXLozqmbT/fff2Fuv8YujzQzytTBzfI=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.w0ssh3ovoz.wasm"
    },
    {
      "hash": "sha256-0NPLZ4kE9BQ2OaNu2gh6hZTMJwxZEwdhPL8b5wRoVds=",
      "url": "_framework/Microsoft.CSharp.kfm9yuy100.wasm"
    },
    {
      "hash": "sha256-9J7ax+L0dQ8VNbJ9wQa4/hWHo2Zp+zQNl7KxhGqKLhU=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.k41dg2oy4w.wasm"
    },
    {
      "hash": "sha256-ZQaMwz+B8lBbLnAzfJQ+wApCDgi0GENGxEinAbBPb9w=",
      "url": "_framework/Microsoft.Extensions.Configuration.9rpw4ifbct.wasm"
    },
    {
      "hash": "sha256-S1bLHT5G1gydX/bZ+wL3Ec/MFla9hRE19jv5pRr+WsI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.tqz3qu0dvk.wasm"
    },
    {
      "hash": "sha256-09zipNk6DJDNqGYn+FYMEQiyvNfRmU7bNAcFxOpcNCs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.56talnw6fw.wasm"
    },
    {
      "hash": "sha256-E6vhxF1xAbRO9cmPUYmrZuCayNbQwg1oq/c1KXi3C1o=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.z0vgmhrln1.wasm"
    },
    {
      "hash": "sha256-D4IKq4gTg30T2WLzZdTsGHeudWFg1oV2l0tVW1Fs3bk=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.3v7h08qab2.wasm"
    },
    {
      "hash": "sha256-B5XjEypRdiCAdclTjArDbIbWY39cs4QSABlghv57WCo=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.hu75ojzlh3.wasm"
    },
    {
      "hash": "sha256-A9H2lNpT5LgYVksCwkcJLm4Xbh+BlbdUA1IFjb7Yeig=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bqt2i35hya.wasm"
    },
    {
      "hash": "sha256-FEJ0AI7EZyQKyR/RCmUGe/cX62fjrRMMNJ8U/e16aNM=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.wpf2e66y5e.wasm"
    },
    {
      "hash": "sha256-ptpsxTSAZV8eeOuZ5JBZlFYef8rpz7L+1bb1rrqc8ME=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.6cr5dhj6ft.wasm"
    },
    {
      "hash": "sha256-peJU98fk9vTz0R/+O81n/4CZMwu95VfLhH9hRDgBgms=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.r4jikqj266.wasm"
    },
    {
      "hash": "sha256-pm/UlHKYTa0MR66RzFHOcDjunbZZD0SFqJfIiTrlafI=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.yxi3pter98.wasm"
    },
    {
      "hash": "sha256-DBudzhvwBklS/rzTgbzvtXADWC7E7/A6TL6SQ/b3Q3U=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.8dnb0sugn7.wasm"
    },
    {
      "hash": "sha256-XHaDq22dAzVhJoLzLafgEufO6sXNHHwC0nNM4usNbi8=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.46os95nnpm.wasm"
    },
    {
      "hash": "sha256-6KTi7XSetncK3IWBIlIGHd1HRwfiDBkcEzCg1yG6174=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.s3uaucuyu9.wasm"
    },
    {
      "hash": "sha256-Wakfv68W6c7KIL+LJnD4k8sLR2C5xy5lYWSXHoM/Y2M=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.31oo3lfiw4.wasm"
    },
    {
      "hash": "sha256-CvF1oB4KajAMDT6w3eb+WD2UzweG0XvzW/HahCfLjTw=",
      "url": "_framework/Microsoft.Extensions.Localization.encwtjc3mu.wasm"
    },
    {
      "hash": "sha256-AKKgDitRWaOE/dfd4TGdVoj1UFWDQjE4n2oM9PYrams=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.0golvgzk7y.wasm"
    },
    {
      "hash": "sha256-6M/X94so6mDJTi24LtTG+4NfmoTOBr9JRMGR+1PYIe8=",
      "url": "_framework/Microsoft.Extensions.Logging.g6renuo6ud.wasm"
    },
    {
      "hash": "sha256-1HUSw4azH6pDocI50Db0aNhWaE5k3jpb3hN2vhCQ6w0=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.sy3zn47g40.wasm"
    },
    {
      "hash": "sha256-9q0IWDCY2KuSgvNlUJlul1gBB5j5ymJCdl5EJZmBtnU=",
      "url": "_framework/Microsoft.Extensions.Options.yub4h79uz0.wasm"
    },
    {
      "hash": "sha256-hC/FEJ8CJ60guV8fqHSrBialdB+EeA4XykU41qTMn/w=",
      "url": "_framework/Microsoft.Extensions.Primitives.8nsenkuiw1.wasm"
    },
    {
      "hash": "sha256-9T3XO8THG/2cTkjjnHbxuW6w9dIeKuVriiIB4Jh4kBs=",
      "url": "_framework/Microsoft.Extensions.Validation.3y05m210dk.wasm"
    },
    {
      "hash": "sha256-ZLnM8EPLOmcOVulO7qjanoihqZacece0sRoSgjGKI5s=",
      "url": "_framework/Microsoft.JSInterop.44tczavxny.wasm"
    },
    {
      "hash": "sha256-z2RuUgPel4iTe7O28sT0HMYBEhufKpHteeVIrrpNFM8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.dd1hyeex4f.wasm"
    },
    {
      "hash": "sha256-PrxO3N6JI8GjJnmc2msGgSqGa+qYiPZ8WqYupfV9/ss=",
      "url": "_framework/Microsoft.VisualBasic.Core.qyqh186u4r.wasm"
    },
    {
      "hash": "sha256-Xn5Puf6Al0ujUR+G3dY3hzDYS76EXv68xwIyI+KDNZM=",
      "url": "_framework/Microsoft.VisualBasic.utvux904of.wasm"
    },
    {
      "hash": "sha256-KPKt4Xc2PPw/pJ8oxmM3qyYTLHy40rQuKE1nM6FxO1I=",
      "url": "_framework/Microsoft.Win32.Primitives.s32a1m1goq.wasm"
    },
    {
      "hash": "sha256-RuC1O/ZTLqzkSzeuHwAneGkqFjgQ4Pe5UV4NFa9T51E=",
      "url": "_framework/Microsoft.Win32.Registry.6lka1uke1h.wasm"
    },
    {
      "hash": "sha256-iqeU5ciIv9qAAkvYUTnXk1A4YdpG7mhyelt1Q/LhH7s=",
      "url": "_framework/MudBlazor.Markdown.6sg6q1wb3o.wasm"
    },
    {
      "hash": "sha256-sHH4J1uNyInShdHjS9gae0TnRVRxcQM33rT+Ki32Niw=",
      "url": "_framework/MudBlazor.w0nnubp9we.wasm"
    },
    {
      "hash": "sha256-YJVSHeDpv06SegDR/EpbtLWq8aXJqw1cf5CXA6t6f/8=",
      "url": "_framework/Shared.0cnu59bwmt.wasm"
    },
    {
      "hash": "sha256-FwYzr/HE2EeXMo2jaeOgmqwn6I+tUZahrUJN0kTNXzs=",
      "url": "_framework/System.AppContext.tj2sa9zr5x.wasm"
    },
    {
      "hash": "sha256-Bepey2yzvnZrZS2fhgdypPArD4WCL1eXTU1hH6+UC/k=",
      "url": "_framework/System.Buffers.tqcydyowiz.wasm"
    },
    {
      "hash": "sha256-udWPFpbWlF88JKkrnMyutoCPeZtNnIkTx/hEQnbcZ8c=",
      "url": "_framework/System.Collections.Concurrent.lthadgv4h5.wasm"
    },
    {
      "hash": "sha256-pR+mZAvS4fxkHl2uNA9yZ2MYZSpgMm0XeZd9sQ2jM2M=",
      "url": "_framework/System.Collections.Immutable.l0he6zyypw.wasm"
    },
    {
      "hash": "sha256-0nNI661rsvGFohc6226vgIz4gp3SW0iIdBmS9PRKXUw=",
      "url": "_framework/System.Collections.NonGeneric.ad1pxu81mf.wasm"
    },
    {
      "hash": "sha256-nNnRM4XSkLPbeB2FU+WkG5e3fMVGlCp/3A0+iVo/bXg=",
      "url": "_framework/System.Collections.Specialized.gtk4obwfrf.wasm"
    },
    {
      "hash": "sha256-j5FWPg78kdV/irMkN/a9Hul+XzxOiw0E0LqUsXtlBlI=",
      "url": "_framework/System.Collections.zra07ht1fn.wasm"
    },
    {
      "hash": "sha256-hJAp4YkPxz7/ka1jCQNiRN1m9Jn0WaPEMEzS8qlrQXQ=",
      "url": "_framework/System.ComponentModel.0r7pscf5u4.wasm"
    },
    {
      "hash": "sha256-D8/wiGEr02FavcWX+/zIXepD7KcXuGeKh1qjL5llKtw=",
      "url": "_framework/System.ComponentModel.Annotations.nqt6nbrn32.wasm"
    },
    {
      "hash": "sha256-XG6fnafukVMgSrczsbOioEt6nssqOUN+qC6g6e0VAOk=",
      "url": "_framework/System.ComponentModel.DataAnnotations.4e6cnvzxii.wasm"
    },
    {
      "hash": "sha256-80dAxEoAcLpzzuDNEjyOKba2Mwtl7PAcXTeuYMNc+6k=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.nbp7w77b68.wasm"
    },
    {
      "hash": "sha256-Bfjz6nRgx113FuriRkaBykevaBfl0yr+29M3lXbWgWs=",
      "url": "_framework/System.ComponentModel.Primitives.9j1l9lir7m.wasm"
    },
    {
      "hash": "sha256-vzI5K7pxJdneWftxJT0Ykx1RSK//5DENcBtTSKtKMRI=",
      "url": "_framework/System.ComponentModel.TypeConverter.punqig44zl.wasm"
    },
    {
      "hash": "sha256-d5itzP7s6tFm83lV1OEIBoEzEJPfrhR8Ws78tB1dq8k=",
      "url": "_framework/System.Configuration.fy2yd6l86x.wasm"
    },
    {
      "hash": "sha256-wUuQHqYEE70QCaL7xHMGtfuHU54LKZWGTEC0CJIA+JM=",
      "url": "_framework/System.Console.5jthgzyw5m.wasm"
    },
    {
      "hash": "sha256-bGygeNKDZ+N9tqHVmirIuq01eGHkHDEniyT510iRLpE=",
      "url": "_framework/System.Core.wvv4updlri.wasm"
    },
    {
      "hash": "sha256-ThW+GEOBdAGr2jgj+UoWW4TWsq2J5as8lwnV7GMQ6go=",
      "url": "_framework/System.Data.Common.285h6coz0g.wasm"
    },
    {
      "hash": "sha256-O4Lu0yAtccpmVCTX10NMktWkyTVGSx5zVfl6sLL5bXA=",
      "url": "_framework/System.Data.DataSetExtensions.7lsumcpq6l.wasm"
    },
    {
      "hash": "sha256-H7XnrUjWPt0UF1jktJy0SJYOOkG9QCLWhsgxsND74Ck=",
      "url": "_framework/System.Data.z70c9476z7.wasm"
    },
    {
      "hash": "sha256-VguMGR/TC7QXX+3bHcecy8zkN3Ec1Ss158XbU+ZjgDk=",
      "url": "_framework/System.Diagnostics.Contracts.anx05bvtue.wasm"
    },
    {
      "hash": "sha256-/TdXrWpQ7/A3K/k854gs07qtHTKZ5EtRO6A2Vw+rfBc=",
      "url": "_framework/System.Diagnostics.Debug.p9qk64mjqw.wasm"
    },
    {
      "hash": "sha256-O4RWX3nj9APqW2vYQ1GZ+KRWoWf85Sqyw9GQ2lTZQbs=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.xt514l75el.wasm"
    },
    {
      "hash": "sha256-nNwkjpYcSCNSQ0FQxiZ6zaijh05sxrcMIYqE0rR/9dE=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.odr4hy4bza.wasm"
    },
    {
      "hash": "sha256-G2kCLMlmb5K+rhLNg3UhoPRNWRTinzPQrvqTwdiOLP0=",
      "url": "_framework/System.Diagnostics.Process.lc2coeb9zo.wasm"
    },
    {
      "hash": "sha256-ZFWDbAJyxm1cgRbkoHSyhh3HWmCQ3vDQiiN9KG9pa40=",
      "url": "_framework/System.Diagnostics.StackTrace.citkvlllzc.wasm"
    },
    {
      "hash": "sha256-X7Z38o4SoFDleSl3/gGzFdHZEc8JG3AjvCu4WipF9Cc=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.xstzkl8thi.wasm"
    },
    {
      "hash": "sha256-NnrE4Jjz4vuApF5xSX8knVkGaMYyJs30FiQDM3x2P0k=",
      "url": "_framework/System.Diagnostics.Tools.yqw8e0e66k.wasm"
    },
    {
      "hash": "sha256-dgazVBR8JtEC68MqzJnNQhkOhQ7V0GL4ntfCuCIbTWA=",
      "url": "_framework/System.Diagnostics.TraceSource.u6k98s0hvt.wasm"
    },
    {
      "hash": "sha256-BVULOztO/NH1rifbDKYjMoyCBHf9vzjSoNiE4D6K7bA=",
      "url": "_framework/System.Diagnostics.Tracing.3qtycdw0wr.wasm"
    },
    {
      "hash": "sha256-e+tPOJZQXlKA/uT1+w2jGyaKC6yR9jJJolatRON1/3c=",
      "url": "_framework/System.Drawing.97w21dt5mi.wasm"
    },
    {
      "hash": "sha256-IpcP9X3nY0x8nWAXHC8CI4YdEStp10631dbar15uwiU=",
      "url": "_framework/System.Drawing.Primitives.20mnkxh81v.wasm"
    },
    {
      "hash": "sha256-CrhjXVT99prjJbHnuUEbf4DuDN1jP/W+w3jE2n2RN5U=",
      "url": "_framework/System.Dynamic.Runtime.mk5brvcn26.wasm"
    },
    {
      "hash": "sha256-jzX6ZYhIixmvSb2ABh/UnILhSiqoKtsOS7BoL0RVvFo=",
      "url": "_framework/System.Formats.Asn1.hg6ny6lbl4.wasm"
    },
    {
      "hash": "sha256-gHEzhd4Yo08Fk/B5s6YmnDk8rFJMfaKJ4Rh0W9wapz8=",
      "url": "_framework/System.Formats.Tar.cden59mmah.wasm"
    },
    {
      "hash": "sha256-Ug73E8VxNw3LQh9Sx/Ef3/1olvR7YyGl6HlI2bPi7QU=",
      "url": "_framework/System.Globalization.Calendars.ucibclsw86.wasm"
    },
    {
      "hash": "sha256-EKc+MZjCTrHDjO75131Z3bgwUqXXWrJDmVFklNhAvXo=",
      "url": "_framework/System.Globalization.Extensions.0gje76o1ka.wasm"
    },
    {
      "hash": "sha256-gXgi0WeWGj/s7ZI8YZt1TeJALBiLN6WlpB0oV8jnQc0=",
      "url": "_framework/System.Globalization.zf4sy4xuv3.wasm"
    },
    {
      "hash": "sha256-jTWcrqpwCnqyWvR4jd7Ls2VIVViO5Nv5sXXKvfFCHoE=",
      "url": "_framework/System.IO.Compression.Brotli.7vpa9c5ub5.wasm"
    },
    {
      "hash": "sha256-8CxIkQqn1KblxSnt4mD7A+j4DdUH7Q9f9bqHPHB8PBU=",
      "url": "_framework/System.IO.Compression.FileSystem.0kg93tq43j.wasm"
    },
    {
      "hash": "sha256-KF4Xus2uWg8VrDHmafrCI8t0665cQ5RJ2gRth2n5vwI=",
      "url": "_framework/System.IO.Compression.ZipFile.k995wshqjs.wasm"
    },
    {
      "hash": "sha256-eIpkVellhFiU9fbP2oX9oc4qUPNgs121+UJctjgBH7E=",
      "url": "_framework/System.IO.Compression.kdu78a74gj.wasm"
    },
    {
      "hash": "sha256-vDu8pX+mLya3N5D16gG55TaowaPgGNq+ylN7FNRrOJI=",
      "url": "_framework/System.IO.FileSystem.4ww3vzh0qu.wasm"
    },
    {
      "hash": "sha256-TiRSrMh32m2ATfVm5AayIDKaQuqS54OG7DzRErmWkgw=",
      "url": "_framework/System.IO.FileSystem.AccessControl.qaz87sy4tt.wasm"
    },
    {
      "hash": "sha256-1bjef+ilq1FQ4iHRh8aoHl3+7NMEnMtefV65aD0Xvv8=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.h55bq0nk5s.wasm"
    },
    {
      "hash": "sha256-Ng+4vQZwhPvSlHjRkDxX/DP/y/nn2f+7NXd7RPHo6HI=",
      "url": "_framework/System.IO.FileSystem.Primitives.iecsbmkurv.wasm"
    },
    {
      "hash": "sha256-9vaB+nKf5VufSmdp7I1Mx3Hzu5xvbaSHF2fIU/djelE=",
      "url": "_framework/System.IO.FileSystem.Watcher.mte0a1pd5n.wasm"
    },
    {
      "hash": "sha256-zL6f2y0Tk/Pxu5LeX7geW9dXm8LYx9+ED0v3jx6zYl4=",
      "url": "_framework/System.IO.IsolatedStorage.4opp3obsdc.wasm"
    },
    {
      "hash": "sha256-DUkREVrEAyiBA8grvjQmowobqIwj80AKR3sTwrKGpZ4=",
      "url": "_framework/System.IO.MemoryMappedFiles.ba0qfp8hvu.wasm"
    },
    {
      "hash": "sha256-0B7asSRhpik4vrRfFfWtV4+5Jx/4qe32CRQS4RTX12A=",
      "url": "_framework/System.IO.Pipelines.c1mx5n5sjo.wasm"
    },
    {
      "hash": "sha256-OLCrhS/zxyZiIS41+WQvFhjeWPZVw9a+1QweE3VGuLs=",
      "url": "_framework/System.IO.Pipes.AccessControl.cbm5cx4n9i.wasm"
    },
    {
      "hash": "sha256-jiy2oFD1zWhSmSInr3Ni4vvlfOGX45VgeU+iiBLcSSc=",
      "url": "_framework/System.IO.Pipes.egon9m5hzh.wasm"
    },
    {
      "hash": "sha256-Yl7AgriGmHQ3EIcM84h/9rhQY9rbyauc/zCONX8vgI0=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.6fwpq17y7d.wasm"
    },
    {
      "hash": "sha256-JQEvjPOUWXdMqZxQ/n/4GkOqIGgkAe9ABwl8m0VhJ8Y=",
      "url": "_framework/System.IO.x9soo596wt.wasm"
    },
    {
      "hash": "sha256-HuoKNTJJ+yEittYMxD5seG9xDOwuoiX9U4gXEUu4w6U=",
      "url": "_framework/System.Linq.AsyncEnumerable.ivr0xvsc6z.wasm"
    },
    {
      "hash": "sha256-VrubXsnHe2+Km4ekTTekTk40Xpc0fa+RKxLGNw6Roi4=",
      "url": "_framework/System.Linq.Expressions.iqneteaoxs.wasm"
    },
    {
      "hash": "sha256-JK51pB+YEjjIgDI1w8rRWWO3VDdYp081P312JoAFFRk=",
      "url": "_framework/System.Linq.Parallel.s4zwszxfmp.wasm"
    },
    {
      "hash": "sha256-/B6sXvxYp0i8ypwIXw8ZCbgJSUUXOMcOBoA+EV/Hvbg=",
      "url": "_framework/System.Linq.Queryable.c2r4b1jfkl.wasm"
    },
    {
      "hash": "sha256-sz4wggUh1zaogavOi/0GVvLj80CA3c+8XT2v6Vqygak=",
      "url": "_framework/System.Linq.dcl9hzdsug.wasm"
    },
    {
      "hash": "sha256-k6cauYdX66m7XIek/abItfd1B9d3Yy0O7hd88/E21i0=",
      "url": "_framework/System.Memory.dgudlqqov0.wasm"
    },
    {
      "hash": "sha256-MhAWqdkkAiAlIHe4KwOtujaC1F3k7YT0jkYyQ6gU/BE=",
      "url": "_framework/System.Net.2gnm43o499.wasm"
    },
    {
      "hash": "sha256-UEUeDwEbiXiOGHbS0ybe9/GrJF7kihRlll4LndrDLzg=",
      "url": "_framework/System.Net.Http.Json.sluvyrihbu.wasm"
    },
    {
      "hash": "sha256-WBzq8PgjOnIpe5rdvYNyo6iJDqIbSyvF35QhPGCD18E=",
      "url": "_framework/System.Net.Http.c7tmrl7o78.wasm"
    },
    {
      "hash": "sha256-4VTuekktXsooPooCm0s93MTNqfVHVKoURzGNDMj17Os=",
      "url": "_framework/System.Net.HttpListener.pu5tmfe9ry.wasm"
    },
    {
      "hash": "sha256-ZmQhJLXcwe9h4UGN46hRXaM/3V/M2vvye0rUFtEQUHQ=",
      "url": "_framework/System.Net.Mail.aj7pi0mjg2.wasm"
    },
    {
      "hash": "sha256-cr5qWsOv3RCFdKwUfnA/aG0PiylO1wsXE7i0lwO0C7s=",
      "url": "_framework/System.Net.NameResolution.62obb2odzi.wasm"
    },
    {
      "hash": "sha256-rx3Qank9GaI+9LmiUIUMKDZfp7lufZyP3HXPfQSrIj8=",
      "url": "_framework/System.Net.NetworkInformation.jn2lli2d0w.wasm"
    },
    {
      "hash": "sha256-F+9srYn1LpjTjgZbycSpO7T9v9NtnwqPDD/cKDUXsYI=",
      "url": "_framework/System.Net.Ping.hanopjymx7.wasm"
    },
    {
      "hash": "sha256-CKx2T86jV5a0ruum8c9GGBDfIYiP1tKVh4KlQFs6bjc=",
      "url": "_framework/System.Net.Primitives.wavmo5w73l.wasm"
    },
    {
      "hash": "sha256-9jOmC06PsGBdGICIN0JZJySqW197+Qy3+ZJZKtxu3Js=",
      "url": "_framework/System.Net.Quic.y9dv3vqaru.wasm"
    },
    {
      "hash": "sha256-U9ZXJ9Tp+VVWUiSNqwxqQoSqDmUYb/eXmesHiapp5Fo=",
      "url": "_framework/System.Net.Requests.jkr3410s9z.wasm"
    },
    {
      "hash": "sha256-crH+2/wc9FDrYszRbo/bf8SU8M5xYOImg2H6t6XEIjw=",
      "url": "_framework/System.Net.Security.6mn4ataiep.wasm"
    },
    {
      "hash": "sha256-ZcPKqsFSlVVjLrKuKHHZacSHWPJ5rmDSexNJJj5JNRE=",
      "url": "_framework/System.Net.ServerSentEvents.pr0qxfqtua.wasm"
    },
    {
      "hash": "sha256-81vrJqWQiDCi2wWEpf5BWm/2BoQsBEDDOQUdLfxDt+I=",
      "url": "_framework/System.Net.ServicePoint.hrryvx0dt3.wasm"
    },
    {
      "hash": "sha256-YmEYJs8/g5z9pom3lBxR5BKyINq61nE8Fxl7PPRju+0=",
      "url": "_framework/System.Net.Sockets.eglsbm093j.wasm"
    },
    {
      "hash": "sha256-zX2tKFWRjLOfBLkerLAau1m1xJ8iZcfnCIckK/4m9ag=",
      "url": "_framework/System.Net.WebClient.v9l6hoop95.wasm"
    },
    {
      "hash": "sha256-VvyYHp8Q3ssPLm1bmrz+YVbd8/8kvIGQZ2Mg1TEiG+w=",
      "url": "_framework/System.Net.WebHeaderCollection.yx5lbk3szr.wasm"
    },
    {
      "hash": "sha256-M63oBrvsCvli8ivOOT/IScK9krO19KgC9StBzOw6s2o=",
      "url": "_framework/System.Net.WebProxy.34ebpqfxjg.wasm"
    },
    {
      "hash": "sha256-DPwGfheu7KtqrLkHC1ylDF2tMPeRKSmjHPAw4kFivzQ=",
      "url": "_framework/System.Net.WebSockets.Client.kq11xbrjuo.wasm"
    },
    {
      "hash": "sha256-DLXzFSPd/O773PN/iWurS/mK5naZOp/k9fginMzCt+s=",
      "url": "_framework/System.Net.WebSockets.w9x69tmvfu.wasm"
    },
    {
      "hash": "sha256-Jbc4GP+6QgqFhJuwV8uUZDr8fRplg6FnDQThDhirPQk=",
      "url": "_framework/System.Numerics.Vectors.bw93k8orhp.wasm"
    },
    {
      "hash": "sha256-PF0ay2URV+SpCOv5heEZqGFpTIMC4oP+ZZ3gMDQaPqw=",
      "url": "_framework/System.Numerics.g5sh2mqcdn.wasm"
    },
    {
      "hash": "sha256-VYfXHurqhN3H6YBASulimU9FyHHi3oB8I81EdFIFF5w=",
      "url": "_framework/System.ObjectModel.vzy23y3uzd.wasm"
    },
    {
      "hash": "sha256-SLqkvMoC8pMigajMWVibrzztLIhs4JU+/Eq8eQ2bcNg=",
      "url": "_framework/System.Private.CoreLib.sz4ghvrgd1.wasm"
    },
    {
      "hash": "sha256-TNXDfN9xkGfnlWYorT4wvzwVFT45Fold9aTRK7Zvqkc=",
      "url": "_framework/System.Private.DataContractSerialization.silvgrpf2n.wasm"
    },
    {
      "hash": "sha256-O0mg+ucaWvXvrba8P5De6vKriGxlRzlqIs7E6DsVKxY=",
      "url": "_framework/System.Private.Uri.tie9daveb3.wasm"
    },
    {
      "hash": "sha256-OCaihxbUNRFSWfv9Jy+LX6YQDKQZzpL+U04neJ6I/5w=",
      "url": "_framework/System.Private.Xml.Linq.02fc3z4z55.wasm"
    },
    {
      "hash": "sha256-FBqxp5eZsSrh3BcZti6sUhjK4sNf8MFAnFV0jNPKpyA=",
      "url": "_framework/System.Private.Xml.opp3lj2zbn.wasm"
    },
    {
      "hash": "sha256-JvJFHDbmSfSM0BX12cau5HUnger1b7zGtJBSrTKhQGs=",
      "url": "_framework/System.Reflection.DispatchProxy.2y1slkljkm.wasm"
    },
    {
      "hash": "sha256-edHA1Dz3yeUZ9QowabDkyorZy1IxOn6eje0Z9i2HJB4=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.59rukqv3sj.wasm"
    },
    {
      "hash": "sha256-yHFwFtvcr6ijke9AEjdS253FpFGf2LthTQQwI4wG5PM=",
      "url": "_framework/System.Reflection.Emit.Lightweight.gqgu2rt6xn.wasm"
    },
    {
      "hash": "sha256-c0WLh4BT29Z0krq9Xt4JBN1lx92dfc8s58aFdh1J98M=",
      "url": "_framework/System.Reflection.Emit.fh0sc2wmvp.wasm"
    },
    {
      "hash": "sha256-JaO8UgBnVEea6Y0ZWFFY/dMUDCvrfBjEi59G60vXj+M=",
      "url": "_framework/System.Reflection.Extensions.vb7jl7kjxx.wasm"
    },
    {
      "hash": "sha256-ohrjE2wNnS9juG+35mR2iUNVQqpsyqG6/FUOX+MAEU4=",
      "url": "_framework/System.Reflection.Metadata.63biykq5zy.wasm"
    },
    {
      "hash": "sha256-9SzCQaIfydFPtuB3jI5o5W4YluZy9D6A69jJC0ICmB4=",
      "url": "_framework/System.Reflection.Primitives.x13qrcnytc.wasm"
    },
    {
      "hash": "sha256-089rgin5L0hJM4aXdpK7ECpPxr0ugJ0EDJeg4nhiWsg=",
      "url": "_framework/System.Reflection.TypeExtensions.re89t4b7m5.wasm"
    },
    {
      "hash": "sha256-hhdIgtdL9AulbvCUkwYtGpzc++ce+V/WWVRisQx14tc=",
      "url": "_framework/System.Reflection.uvcxdfqzxu.wasm"
    },
    {
      "hash": "sha256-EBeG1/12c3JE1jS4cMCRsLLOX0E0lJrvgMIbb2eEfN0=",
      "url": "_framework/System.Resources.Reader.oir35l1zu5.wasm"
    },
    {
      "hash": "sha256-6M61/HW+4wK6BNLEonQau4j2e9JxPQKZOFzI944Eb/Y=",
      "url": "_framework/System.Resources.ResourceManager.4twwn3qfsb.wasm"
    },
    {
      "hash": "sha256-rY7P6DIVejjDGm3uNGkj74iz90HKhRmJrQlgEYmZrXo=",
      "url": "_framework/System.Resources.Writer.3k06dva2yo.wasm"
    },
    {
      "hash": "sha256-Ap9BLeqYqbpW4Zyh0LUtIZrp/9NTSmXMqp68k1YEMe0=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.issto093zc.wasm"
    },
    {
      "hash": "sha256-6ffW77F2Gn9lK8O9x7Zh/JuA3wU3ImpaX4febZ6Sivk=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.9ocfasplqd.wasm"
    },
    {
      "hash": "sha256-g3A4ELhyFel0Sj13w9xPExW9GTUnh8Xpf5TLSWFggGk=",
      "url": "_framework/System.Runtime.Extensions.bivwtb0v3y.wasm"
    },
    {
      "hash": "sha256-McOX/WxvmG2QZrgxPetiMc+XRSPhZbxE+1Piof4h8zM=",
      "url": "_framework/System.Runtime.Handles.7u1q1wl1do.wasm"
    },
    {
      "hash": "sha256-837/pYCcCyG211ihuiLLu5r3188vAADAi0yd5DykD5E=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ppvmrbz86k.wasm"
    },
    {
      "hash": "sha256-ZYD6M/ETwPAoVY2X29dmfaj7jK+71cO6QM/NvgKedRY=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.ty0izun4ef.wasm"
    },
    {
      "hash": "sha256-vqrsJ9Mskk06KGdZQlhYrvHY/UEk0WrFOVwsNNid61I=",
      "url": "_framework/System.Runtime.InteropServices.axpino88we.wasm"
    },
    {
      "hash": "sha256-T2RhZ+yL3qZEGsrTB2+O5Gt8LwpNiQ3CrRj1gbprdcs=",
      "url": "_framework/System.Runtime.Intrinsics.v8t1a4cu19.wasm"
    },
    {
      "hash": "sha256-9B3n2N2ukhYH3Hc7ZyGc0VITOqsD5cEBr7oD3GVU5iM=",
      "url": "_framework/System.Runtime.Loader.obpjv2xpwl.wasm"
    },
    {
      "hash": "sha256-+V+qaWAYeqEx34I3ToqZp3rLWlL4LQnAu7wKXj3LFww=",
      "url": "_framework/System.Runtime.Numerics.lhwe0p8dkk.wasm"
    },
    {
      "hash": "sha256-nGI2krKyRpSBN6ETJpKI8baQpwN8U78GjDt8mgqjJjw=",
      "url": "_framework/System.Runtime.Serialization.Formatters.wh2npalni6.wasm"
    },
    {
      "hash": "sha256-UQ364oHQfVb16yqBdWwdOPQpDwI6rIp3XSWX6hMhbz4=",
      "url": "_framework/System.Runtime.Serialization.Json.rd8tbegpxn.wasm"
    },
    {
      "hash": "sha256-D5rn66MdSREPgg3B28/d/gj7eR2JvgYHTow3mJOYQds=",
      "url": "_framework/System.Runtime.Serialization.Primitives.b94e91wdpi.wasm"
    },
    {
      "hash": "sha256-46ucJPdA8RgAkFiwelu8crGMSlrrewfGsLuX6i58i1g=",
      "url": "_framework/System.Runtime.Serialization.Xml.n3mw830utk.wasm"
    },
    {
      "hash": "sha256-RfbiIh/uxHBFoUTQjTFCJdg9jBiVl6orpDCeJLcAPz8=",
      "url": "_framework/System.Runtime.Serialization.xtl39bnlne.wasm"
    },
    {
      "hash": "sha256-FTeTJ6JpT3jgwwZugukQtlbiBKiQYnSGFecEVgUpJgY=",
      "url": "_framework/System.Runtime.fz33mzlcvb.wasm"
    },
    {
      "hash": "sha256-UdGIkAtRnwXKbCKrJ42WdQC48cMY+6c9/9AzftOEs4I=",
      "url": "_framework/System.Security.AccessControl.nyx7rr8fg8.wasm"
    },
    {
      "hash": "sha256-GAbAVK/cjIv5EBnavCR4wV5MQKL0ZAtva8XcQEiZUI0=",
      "url": "_framework/System.Security.Claims.klyjsqs37e.wasm"
    },
    {
      "hash": "sha256-Z/6ke7eCglQfYDkeJEhRY+Mn3ZoTdW1DpQvk8TB2O84=",
      "url": "_framework/System.Security.Cryptography.Algorithms.zhm2cphi9n.wasm"
    },
    {
      "hash": "sha256-eRq+X0/yCbU127ZktpKBIPg9jE5M5H6GxBKtdV9P8+U=",
      "url": "_framework/System.Security.Cryptography.Cng.lhk304sl0o.wasm"
    },
    {
      "hash": "sha256-rliNr7O12WrHdeHbXDSwSZ43HbYHAopjlzfZOT1o29U=",
      "url": "_framework/System.Security.Cryptography.Csp.2ortabmjec.wasm"
    },
    {
      "hash": "sha256-vsqgwLyD9qjibH7eyCgM7HX9wvQo//oYD79daXzCw0w=",
      "url": "_framework/System.Security.Cryptography.Encoding.20cmrdo2bo.wasm"
    },
    {
      "hash": "sha256-fAXPZxIC2XcOYwhUNl1uDFHnz24LRgLnhxHyeqNy5ws=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.85s81dt8ah.wasm"
    },
    {
      "hash": "sha256-f7mysHpIy4CTYGbBlFaxpc+rPfgWV9r1SgrCXmpODp0=",
      "url": "_framework/System.Security.Cryptography.Primitives.pu7zcao7p4.wasm"
    },
    {
      "hash": "sha256-wg9s2qI+eEZEwFhWpQcMnfELIRnrtTj0u6VCits977Y=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.ioxxbrvbrc.wasm"
    },
    {
      "hash": "sha256-AgxEf2wewzz/f/50Tefp2XzOnCdldYT/LKS+y5tnefc=",
      "url": "_framework/System.Security.Cryptography.e0zfden0su.wasm"
    },
    {
      "hash": "sha256-UDCLUE4f5/r0rJ7Dn0eDnGmtBWntpXcpcf4jLnQUHLA=",
      "url": "_framework/System.Security.Principal.Windows.wwlbs0vwsq.wasm"
    },
    {
      "hash": "sha256-hXLe78DMmGmNqGYSPPIA6UTFG/wWxfKDrCBoPgwzOXw=",
      "url": "_framework/System.Security.Principal.b4q1biewgn.wasm"
    },
    {
      "hash": "sha256-sTGRAvJ2qVHzBI+3EGIGfdFf/YeBavoqlZEfh6bjOrQ=",
      "url": "_framework/System.Security.SecureString.new9ysn0km.wasm"
    },
    {
      "hash": "sha256-xDFVtJbJu7IkaO/fTyNk9+fxDuiAU63JeBwPtAdG4LQ=",
      "url": "_framework/System.Security.wxc1i6x8wl.wasm"
    },
    {
      "hash": "sha256-p09u3jjoeQpiVUSFLegnxXrljK0JgG+g7KfwjdMGwSY=",
      "url": "_framework/System.ServiceModel.Web.3dl2nctyqn.wasm"
    },
    {
      "hash": "sha256-Y42CHp5NLIprnTWdnKJlllY/JCDzLwDiJ5PyS0oDL1c=",
      "url": "_framework/System.ServiceProcess.fhfgntluxv.wasm"
    },
    {
      "hash": "sha256-o3z5e4RqCMXqGpmETXGSj8xRJfuJJVEBdSoqh8aDmSs=",
      "url": "_framework/System.Text.Encoding.CodePages.9lyl53lq8c.wasm"
    },
    {
      "hash": "sha256-o+ncic9aFNpEPPsEBXz9O2i8/fomjK7CpQpYdP+Q/98=",
      "url": "_framework/System.Text.Encoding.Extensions.rycc9dq23j.wasm"
    },
    {
      "hash": "sha256-0q0g9jF4WfVgzeUHNQwOW/V2g8/3p3jDPuIbcLGJvRo=",
      "url": "_framework/System.Text.Encoding.iw4g18zh5w.wasm"
    },
    {
      "hash": "sha256-kp9NIXd+D16rRRH61ztHbawVFRnkzp3URMYdfAMt0oI=",
      "url": "_framework/System.Text.Encodings.Web.ugxo1k3sqb.wasm"
    },
    {
      "hash": "sha256-YeeQMlg/dgUAQyNnsLoQ4vned9yIRXfCG9H92PndR00=",
      "url": "_framework/System.Text.Json.dlm873fi9n.wasm"
    },
    {
      "hash": "sha256-teJ7Y1SN1DaV4NHhYiA0fWe/kpexl8CEjancTbejrPw=",
      "url": "_framework/System.Text.RegularExpressions.vb2y1bjgj2.wasm"
    },
    {
      "hash": "sha256-61CSEHptGC/QKQMRAFXzZg7dee41ZNlETHrz4vgQmas=",
      "url": "_framework/System.Threading.AccessControl.pn8lsdyqsi.wasm"
    },
    {
      "hash": "sha256-VwSPojIABvPr2/UCmCF/hW6sxUj6nXAbngg6MLBsWs4=",
      "url": "_framework/System.Threading.Channels.psyi3umkjj.wasm"
    },
    {
      "hash": "sha256-4E/oiYmuFxEMVhGnjs+smjZGeCzAbVvl6fNnmdQDms0=",
      "url": "_framework/System.Threading.Overlapped.c1vzk9j1mj.wasm"
    },
    {
      "hash": "sha256-ybZo6W0zGuPHm+fxUpxVMdoxgax/hdFotncYWTTmC70=",
      "url": "_framework/System.Threading.Tasks.Dataflow.varkygmqpc.wasm"
    },
    {
      "hash": "sha256-GRGTmMUl60Lt6JlTqpIlX1TSV7bmSR3DAXaN2bj4Ou8=",
      "url": "_framework/System.Threading.Tasks.Extensions.vmfz9vnzaj.wasm"
    },
    {
      "hash": "sha256-YFOJhd87Q7dJcOUWFzY8yHyiBH2eq2LJJE8IwsBdZV0=",
      "url": "_framework/System.Threading.Tasks.Parallel.4naydz1lda.wasm"
    },
    {
      "hash": "sha256-qSbbDTfEY7ntu6+sJQEWZSbbiqPI3sLq2dks2ar34pk=",
      "url": "_framework/System.Threading.Tasks.b3m2dkom2n.wasm"
    },
    {
      "hash": "sha256-Tlu4iGukx+zrVF0PXPYpvK2ORq9zSVRV37eqanZ3jjE=",
      "url": "_framework/System.Threading.Thread.qy1njmr2fl.wasm"
    },
    {
      "hash": "sha256-R3zD+q2ND51siSNfqRr0IjEAov//ZebgECfn3Y/ZsC4=",
      "url": "_framework/System.Threading.ThreadPool.verm800txi.wasm"
    },
    {
      "hash": "sha256-iHYAbimfVbJKJywQDW9YbcXbKYICZkdjAmQ6u+gtr5g=",
      "url": "_framework/System.Threading.Timer.gapebxrttj.wasm"
    },
    {
      "hash": "sha256-YtrF7VnJUyybpUmDt4JSdkQ4LpGStYtg/kpbGt/3sbw=",
      "url": "_framework/System.Threading.e01ehmqnbq.wasm"
    },
    {
      "hash": "sha256-LHcZ52tSm/pROQ985QQNx6vmcO0hDltLOippj0rjmwA=",
      "url": "_framework/System.Transactions.Local.wn9dhhrvrn.wasm"
    },
    {
      "hash": "sha256-5xPNfCnW1SZl9xXjFXmrrNdwBqE92wzSmbhojZ7FJVA=",
      "url": "_framework/System.Transactions.jp1diug9uq.wasm"
    },
    {
      "hash": "sha256-Jo+n6/SjUbD2/rQvDA1nsb1wxJtE5slHtxYncSqQL1A=",
      "url": "_framework/System.ValueTuple.en1u953gmw.wasm"
    },
    {
      "hash": "sha256-fF1oy0GHf7dB3yYWSN7cpZOV5bQDkm6AOAP88s45Jbw=",
      "url": "_framework/System.Web.4i33lta79t.wasm"
    },
    {
      "hash": "sha256-LC7QOyT4WcMt+0125I/aK5k7Wa/rKVqdaEEQhMVnKjc=",
      "url": "_framework/System.Web.HttpUtility.scmk0sllom.wasm"
    },
    {
      "hash": "sha256-/9QJcNO5W3H0GlfiRMPEeP/kuCQD6APrX58v9Xqe7TQ=",
      "url": "_framework/System.Windows.lnjussi7qj.wasm"
    },
    {
      "hash": "sha256-wjO3yIAgB6qszUl3dCHO1uLsH7CpJjqLvrXayAH+ArM=",
      "url": "_framework/System.Xml.Linq.maodw0zvaq.wasm"
    },
    {
      "hash": "sha256-sQrf4S+dN+J5VrvZ+zY8dzWYNB/skPSJjiLEyFjxAwI=",
      "url": "_framework/System.Xml.ReaderWriter.tlye01cwdk.wasm"
    },
    {
      "hash": "sha256-uWchppQkxf7ufJwS7anM5jupv7kzOLM/IKPZ1VIYnmU=",
      "url": "_framework/System.Xml.Serialization.rflrbq684v.wasm"
    },
    {
      "hash": "sha256-J5AiH5QGxsoy6VWbFjnpQLzIipl83ZgwBnWKdkR4/BY=",
      "url": "_framework/System.Xml.XDocument.3hku9dt0vu.wasm"
    },
    {
      "hash": "sha256-c7UazCAffmPlW9CNcGrVG+nHGnyKIEWK+fdo/KE5ESk=",
      "url": "_framework/System.Xml.XPath.XDocument.5mztpustxn.wasm"
    },
    {
      "hash": "sha256-2Tie3WDSfMnVs6Gae7p8bjW4sz1CXIR3r/IxY2xU+bQ=",
      "url": "_framework/System.Xml.XPath.z9o1qrzv6q.wasm"
    },
    {
      "hash": "sha256-IOYhl5DxuGnCh8PbZWM5G4cAt+9O9EuYTYCUC3dSfZQ=",
      "url": "_framework/System.Xml.XmlDocument.4nyqwmf7vi.wasm"
    },
    {
      "hash": "sha256-JbHXU4oICzdeLaeHGz/7miSsNuuMcdbasBe/PhVylco=",
      "url": "_framework/System.Xml.XmlSerializer.5okepy1b7g.wasm"
    },
    {
      "hash": "sha256-Qxbt3zVJFkxl6np9g4fSQL8ySMF2r11rG3EW/OPEAyw=",
      "url": "_framework/System.Xml.vt96jj889x.wasm"
    },
    {
      "hash": "sha256-6Sf9JikQX7X5sJ9LDidOgnjFOnP5ZTeH6WvZZomJpYg=",
      "url": "_framework/System.noiytmvos5.wasm"
    },
    {
      "hash": "sha256-lFnM09hMmV9rWz3TaZyTD3IEiWidgFCycasgDw+wj+M=",
      "url": "_framework/VladislavAntonyuk.o7k9r8jp6t.wasm"
    },
    {
      "hash": "sha256-i6Seushw58YNvHcbvnnxZbrwiSo/z6LkQod95uIJSaI=",
      "url": "_framework/WindowsBase.fz90iktqd6.wasm"
    },
    {
      "hash": "sha256-h5BykV52WXDQQYSSeQYmnw2hLafu9fcAvqRQUCbYr2Q=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wK4d75N7t8qDNB2PXHAvew2pZnWUklx2XJPmmlACEsE=",
      "url": "_framework/blazor.webassembly.js.map"
    },
    {
      "hash": "sha256-aiXgHALPxaqGDi8WwonLrmRvTHD/pCSWF+51R8gr6Zc=",
      "url": "_framework/dotnet.il9oorvtwu.js"
    },
    {
      "hash": "sha256-CGXO5wJDgp4QyoSfSYv0JaZ1uC6L0dqruBFTPjXyxRc=",
      "url": "_framework/dotnet.native.gyn70opcq7.js"
    },
    {
      "hash": "sha256-kl3KCioIefd3enHfxtrrGZHcFqHrgSFx2cuFa/M2WW0=",
      "url": "_framework/dotnet.native.mjledzavap.wasm"
    },
    {
      "hash": "sha256-FsddKLA9kAdfVKI0lZFago0rrc/gNe0yrVtP7+D/qN0=",
      "url": "_framework/dotnet.runtime.uyfhwbfd13.js"
    },
    {
      "hash": "sha256-eZuX0pntrUwNrAmFCMwpxJjFA3/Myi/rW2x9mEZ+Mbg=",
      "url": "_framework/icudt_CJK.5lgyv9xn0b.dat"
    },
    {
      "hash": "sha256-SQcxb+bdx2UXUCU9tFdOWCr4Ctk64xghCnr0JGLWWKQ=",
      "url": "_framework/icudt_EFIGS.xyuimhy3ww.dat"
    },
    {
      "hash": "sha256-T8YllylpxyWp9Aq4AiF+BMAxKXqYyzWB9RA5RqY19vs=",
      "url": "_framework/icudt_no_CJK.h0en30vv0c.dat"
    },
    {
      "hash": "sha256-oaWsn83kD2RPiJ2Gyax4j80eDMS1rB9TO5mP9Ngxu8E=",
      "url": "_framework/mscorlib.x4ni8ean3v.wasm"
    },
    {
      "hash": "sha256-lFYdE0Hvy9n5U9lLXt3r8Bh/9qGltfekIvYwSFowHgg=",
      "url": "_framework/netstandard.co8az3jtr9.wasm"
    },
    {
      "hash": "sha256-dr/k39SHm5QjwppjOOmWO9wyoZGT64erOEYGcth7MT4=",
      "url": "ads.txt"
    },
    {
      "hash": "sha256-6YDjDQii3/yyLK/lJ6vW8sdzBunwKqZneKh3FKWBY9A=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-W0SgoEOvKcn4vM1fRVEgYmj5h0MXziNE7amdSwdZ/30=",
      "url": "data/.NET MAUI CollectionView with Staggered Layout.md"
    },
    {
      "hash": "sha256-U8p4H78E4wp995ZUPu/igElRMPAp4jM/6xIKLhLamOw=",
      "url": "data/.NET MAUI Multi Window support.md"
    },
    {
      "hash": "sha256-LzXPtGh6Fgk8Er55GNj80ouk7uvwXiJb17ShpF4gZaU=",
      "url": "data/.NET MAUI Push Notifications using Azure Notification Hub. Part 1. Setup Azure Notification Hub.md"
    },
    {
      "hash": "sha256-iybg7iqW9ISSJ/gqJQGlDpzRCO5n661WmwFwwCf66ss=",
      "url": "data/.NET MAUI Push Notifications using Azure Notification Hub. Part 2. Setup .NET MAUI.md"
    },
    {
      "hash": "sha256-24GinuA9+90aj2D0IOPKmAzZBp789w4TMCCA3HLZUFk=",
      "url": "data/Adding Application Insights to .NET MAUI Application.md"
    },
    {
      "hash": "sha256-/HcW3lUJUVk+uvbVk+0wdbNVo8bniv7yJpgWC662x9Y=",
      "url": "data/Adding SQLite to the .NET MAUI application.md"
    },
    {
      "hash": "sha256-BgH+mqXZH+dE6mPwNBEGoTrm7ColB4S46eUFXG/cpCQ=",
      "url": "data/Adding custom action button to .NET MAUI Shell TabBar.md"
    },
    {
      "hash": "sha256-c8OPROsWXXfzBOG6GyuNIFX0r9ZlMxjN8cJnbuSOiGk=",
      "url": "data/AppIcon Badge with .NET MAUI.md"
    },
    {
      "hash": "sha256-/P0q1VMOXKNsqMVvwm/LTd2eoTw/uhlZpxRSTPVjVY0=",
      "url": "data/Azure Active Directory authentication in .NET Aspire Distributed Application.md"
    },
    {
      "hash": "sha256-akDjUVIkllJzBjjhssudWnN4ZH5+5hNvbarxSNarBMg=",
      "url": "data/Azure Active Directory authentication in .NET MAUI.md"
    },
    {
      "hash": "sha256-GgLB/qdf3NE28tBhBmcESQEghQ0kwGGGfNrYI8LmvNE=",
      "url": "data/Building Dynamic UI with Decision Logic in .NET MAUI XAML.md"
    },
    {
      "hash": "sha256-QCeK3gcwM1XsbuBnyyFB2fz2GbNwGLf+UgcOZpxt5bg=",
      "url": "data/Building a Zero Allocation Dashboard with SkiaSharp and Community Toolkit MAUI Markup.md"
    },
    {
      "hash": "sha256-zEpDhggYjY+OOrGxVBaycGOrEZm6ejpxFihBIt75F+E=",
      "url": "data/Built in authentication for specific pages in Azure App Service.md"
    },
    {
      "hash": "sha256-guOM0e/4S175gF4UF3fgGX91YWNAElMnkMn03jbwwlw=",
      "url": "data/Choose the right framework for your next application.md"
    },
    {
      "hash": "sha256-2CWGj6FwHhedhdlLjG0hnIasp9rOECnv1bkm3mvHj3U=",
      "url": "data/Converting Word documents to PDF on mobile devices.md"
    },
    {
      "hash": "sha256-kyCznA+mAXAcjSoHGj2a2u3rEpAXOqaGOfowetJFVtM=",
      "url": "data/Create a gallery app using .NET MAUI Blazor.md"
    },
    {
      "hash": "sha256-UBI9Vey6GkxgQYtG8VGS52TjJcvTS4En1au3SaH+nuM=",
      "url": "data/Create custom animations using .NET MAUI CommunityToolkit.md"
    },
    {
      "hash": "sha256-SBRLXzYqttcZ9FulpRv+MVPiprrMhyjPqmmwsq+vmZk=",
      "url": "data/Creating CalendarView with .NET MAUI Handler architecture.md"
    },
    {
      "hash": "sha256-LytMQpMT2ND9cgqp2T0dqvfOd9PfS6DL7ZmSsURWG6Y=",
      "url": "data/Creating Kanban Board using Xamarin.Forms.md"
    },
    {
      "hash": "sha256-oC4T5vvoXX08HlQQHE5dfGe8lHLkmQHOGJcCep55w3w=",
      "url": "data/Creating Markdown control with .NET MAUI Graphics.md"
    },
    {
      "hash": "sha256-FlMQ7tgUUM8XeLxIlJa/wALoL5+ZII1fWMQG5hEyKxA=",
      "url": "data/Creating a bottom sheet using .NET MAUI.md"
    },
    {
      "hash": "sha256-JriZ96ljyCE1j1nuV1/rMfZ+QCAdkMMWYf5nmAS8nuE=",
      "url": "data/Creating a card stack layout using .NET MAUI.md"
    },
    {
      "hash": "sha256-TcNrjGs0BibsGQupubMWyMFv5zDbiH7obkpwGEQbAvE=",
      "url": "data/Creating beautiful image effects using .NET MAUI.md"
    },
    {
      "hash": "sha256-P2ALEdY9YU2LiOTsAb/jgvbfrP3LIA/ZXm+IG0wpIQM=",
      "url": "data/Creating dynamic floating action button.md"
    },
    {
      "hash": "sha256-LyP7Mh+/ck/JJpdc5hrFGu1dkAltfvE+YW5FeWyU3t0=",
      "url": "data/Creating screen brightness service with .NET.md"
    },
    {
      "hash": "sha256-lSxE6zUPZSEQ5Wt/Dgc84BTL+IP63Rb4HFARKrDtEYo=",
      "url": "data/Customize map pins in .NET MAUI.md"
    },
    {
      "hash": "sha256-dqETZf3R45nE4Pb8Evc0Pfli0Z1wafcY0yeFQ8WVYq4=",
      "url": "data/Customizing .NET MAUI Shell.md"
    },
    {
      "hash": "sha256-niYFaSR7U+q/MVkumDv2uN5FsVTOmC0mXQOws1lPBhg=",
      "url": "data/Drag and Drop any content from a .NET MAUI application.md"
    },
    {
      "hash": "sha256-HyAR3bKFp1xPWWA32dNvwrdbDhJSB6qBuMj6fMc2k3w=",
      "url": "data/Drag and Drop any content to a .NET MAUI application.md"
    },
    {
      "hash": "sha256-/bRTUOBjBZ09CXSZ3EavrsbWgs5STMTgHOiLTGz9oBA=",
      "url": "data/Drawing View in Xamarin Community Toolkit.md"
    },
    {
      "hash": "sha256-eTkJtv2hv8cSfqr5RepFBINJ3UbdlJvATZpkiMAS1mA=",
      "url": "data/Dynamic configuration in .NET MAUI application.md"
    },
    {
      "hash": "sha256-W8J1nwJLnrqDFQcsIjMleOD6cK23pQslQ4ppjOV2d4c=",
      "url": "data/Efficiently Writing Excel Files with Optimized Memory Usage.md"
    },
    {
      "hash": "sha256-6J4kmwCQusfq+thZzgNiNwTgWHsEv1Zmpr7ciWR86Qc=",
      "url": "data/Effortless Android Library Binding.md"
    },
    {
      "hash": "sha256-uVHGkntCnLsvOXsbrMsjd0JgN1C+QIOusEPY1BaqtAI=",
      "url": "data/Extend .NET MAUI application with iOS Extensions.md"
    },
    {
      "hash": "sha256-2MitvgbgFqXO9mnTon2anENK3hUbZdP7IzUQy4hnX9A=",
      "url": "data/Extending .NET MAUI to Any Platform.md"
    },
    {
      "hash": "sha256-a1DYzsVdzd1S+lmJ1pPlyK83kjnpeUDS8Rm5vFK/EJk=",
      "url": "data/Free offline AI in .NET MAUI Application.md"
    },
    {
      "hash": "sha256-WO9Q/+WTBqAR4nyL/sbyaJnoCE3RLDbnosPjkoe7QvA=",
      "url": "data/How to Get the Active Window in .NET MAUI.md"
    },
    {
      "hash": "sha256-eWExjxY30MCpVmsuLviZll4srENwvL772wvJc7tLev8=",
      "url": "data/How to Reference a Class Library in .NET Aspire.md"
    },
    {
      "hash": "sha256-6ajRLwi86hMNX0WZHv0lg2xTXXlEO+hijQZoc+y+zJ4=",
      "url": "data/How to automatically keep your code clean.md"
    },
    {
      "hash": "sha256-fAN6rYkKs2LaA8rLJi1TBv5UV8tRtkDSCBhMIMnTmrU=",
      "url": "data/How to show SnackBar and Toast in .NET MAUI.md"
    },
    {
      "hash": "sha256-DdfSSxhp/bYSfb/hYire7aJdR+mFuLwftL+/gKMf2nY=",
      "url": "data/How to show SnackBar and Toast using Xamarin Community Toolkit.md"
    },
    {
      "hash": "sha256-XVUqZOjnw+NXDje7gnoAuATL+wpUyPlnZ5rCJTnMCrA=",
      "url": "data/Identity and Dynamic routing in Blazor.md"
    },
    {
      "hash": "sha256-+TI0uQcvMk2xqqI+dxc4Z7L7iA1MnWRyT3eSlTct4Pw=",
      "url": "data/Integrating captcha into a .NET MAUI application.md"
    },
    {
      "hash": "sha256-SV6TTjMvNAid9lJBS1erN9kBIRjRmEtogTif8AGi/W4=",
      "url": "data/Interactive app tutorial in .NET MAUI.md"
    },
    {
      "hash": "sha256-aUpdXit87S85+opNpmUv/f97PKnK0ESMy4cW6IKdz8I=",
      "url": "data/Keeping your .NET MAUI background tasks alive when the user force quits the app.md"
    },
    {
      "hash": "sha256-G1vDzWJlEMtVkwif4BbFWSMtD30E/Rd7vCJkFJIhS1I=",
      "url": "data/Leveraging Free AI with Ollama in .NET Aspire.md"
    },
    {
      "hash": "sha256-7QtyY/j080B+FKE0gN3A7qBfD1v8Sl+ojIIFDca/R/g=",
      "url": "data/Loading MudBlazor components dynamically at runtime in .NET MAUI.md"
    },
    {
      "hash": "sha256-soj6n2nS5f065by9b++6zE8zQRpGsWJ+tuMT34XJCY8=",
      "url": "data/Localize .NET MAUI application.md"
    },
    {
      "hash": "sha256-vGK6SlNVBy89T1kNclGDiFu8cyS9tnPUlEg7a/YAzbo=",
      "url": "data/Mastering Composite Controls in .NET MAUI. Building a TabView from Scratch.md"
    },
    {
      "hash": "sha256-w7NUBm2AwTbVxaPI8EFRra7nZwDqJcb+dQ3MSrQKAXY=",
      "url": "data/Microsoft Entra External ID authentication in .NET Blazor WebAssembly Application.md"
    },
    {
      "hash": "sha256-khVaPzztvIA2+yhyd0NoWLQcmnPS6XPRr4fcBUO5Nog=",
      "url": "data/Microsoft Identity Platform Authentication in Blazor Web Application.md"
    },
    {
      "hash": "sha256-mdEz2i/aZWVbdpWU2LWcLS6oMHVodbGydlc2oVYXOw8=",
      "url": "data/Migrate the deprecated OnBackPressed function in .NET MAUI Android application.md"
    },
    {
      "hash": "sha256-JFmzfWSQfCRmobT7KRMmjdgBFduBgs1sQn01bNWO140=",
      "url": "data/Migrating .NET MAUI from Mono and Tuning Mobile Performance.md"
    },
    {
      "hash": "sha256-1l6iMD4rlU4RQzk15iX+NiIBspYI8nJ6jnfEAYgq910=",
      "url": "data/Nesting .NET MAUI .xaml Files in Visual Studio Code.md"
    },
    {
      "hash": "sha256-JDnrNtvh2ARYOZo+gpU+wRREydP/aCPghxq0sXQ1oIY=",
      "url": "data/Onion architecture in the development of cross platform applications. Part 1. Overview.md"
    },
    {
      "hash": "sha256-/1hNkwnfNBXpzqfVwsDUfeipZm2la4omFoopKuLZ3D0=",
      "url": "data/Onion architecture in the development of cross platform applications. Part 2. Domain and Application.md"
    },
    {
      "hash": "sha256-xjwWe5P26KyRNkIUuxxgxCR41nf+PAqsWHxkzzl8f/I=",
      "url": "data/Onion architecture in the development of cross platform applications. Part 3. Infrastructure.md"
    },
    {
      "hash": "sha256-nJuXJDpUtv/h9LkBsQ6c2MncmJpIPywvz41SJTCA8IM=",
      "url": "data/Onion architecture in the development of cross platform applications. Part 4. UI.md"
    },
    {
      "hash": "sha256-d8RPB1AxKyy3YiR4fXwnO7QeN/BlKbVZ1W5DbCBL5q8=",
      "url": "data/Optimizing Large CSV Data Processing with ReadOnlySpan and Memory Efficient Parsing.md"
    },
    {
      "hash": "sha256-5T4Xq2PAPame4iqQXo5CgdRBEat2HHA0dxFi2Q+zi78=",
      "url": "data/Persistent secure folder access in .NET MAUI.md"
    },
    {
      "hash": "sha256-R/F+PwQ/G98lT4mK1Or8MFXnsWjQAuHt7bxITopcdh4=",
      "url": "data/Plugin.Maui.Theme review.md"
    },
    {
      "hash": "sha256-eJLm7wgDhN56yqxqsscS8ZV26Q/tZSaQzPjz+ws1EdE=",
      "url": "data/Prepare .NET MAUI application with CommunityToolkit.MAUI to release.md"
    },
    {
      "hash": "sha256-35lU9TydnAdilMTjcSgDPAqmZS/6XC66qCVQ2+0g3w4=",
      "url": "data/Prioritizing Test Execution in xUnit v3.md"
    },
    {
      "hash": "sha256-7VnLVieBHENxsjCMr3lpdPJ7GyPth0pr+PAe+h6iORU=",
      "url": "data/Real time live tracking using .NET MAUI.md"
    },
    {
      "hash": "sha256-qm62QU2MF3et7Nu4VHLlSplj4uOjyJLfJG9l5dWCQak=",
      "url": "data/Replicate a bank application UI using .NET MAUI.md"
    },
    {
      "hash": "sha256-OXOeAVEZ+uYazA6PGQb36UbLr9W74Nm8URz/7R5m/pc=",
      "url": "data/Secrets of successful interview.md"
    },
    {
      "hash": "sha256-hbyxBMG7idmkWuTQot4t904WX8QnUF1qGsMjy02Ykr4=",
      "url": "data/Secure .NET MAUI application.md"
    },
    {
      "hash": "sha256-4cvzUkSnCwKp1VsPsy+/zPuihArvLwEZF6jHIYdDMVE=",
      "url": "data/Setting a cursor for .NET MAUI VisualElement.md"
    },
    {
      "hash": "sha256-oTPb4IIKTqCq9YSHqygL3qBctO0xl9UAcK2K3fhRtKU=",
      "url": "data/Simplifying .NET MAUI App Development with Debugging and Monitoring Tools.md"
    },
    {
      "hash": "sha256-bGfr+zr3UQBZXAP54cngObMrN1y/kWLV/HEuQpE948c=",
      "url": "data/Speech recognition with .NET MAUI.md"
    },
    {
      "hash": "sha256-TkhPUQ/Jb4F6yFerq6riAOUOT/dONLpgBWvihnMYyQA=",
      "url": "data/State Desynchronization between .NET and JavaScript.md"
    },
    {
      "hash": "sha256-QcrDQulx5Xl0ie67cVEhUbrcsrSJSEspxuvPcl6LKgI=",
      "url": "data/Take Your .NET MAUI Testing to the Next Level with Maestro.md"
    },
    {
      "hash": "sha256-jkWa5rS5NJD9PfFGnEEGk6Aci0E58Svzy1izmjezMZU=",
      "url": "data/Targeting Specific Runtimes for Platform Tests.md"
    },
    {
      "hash": "sha256-bvoxUmyS/IRBDk6bfE04qcZ89XziuKoDVFslOASm388=",
      "url": "data/Technical Literature Review of Clean Architecture with .NET.md"
    },
    {
      "hash": "sha256-LQQFrUGN7bqi8RKGyfX0syAL4L6hLMEs7GDMNl5SL9Q=",
      "url": "data/Testing .NET MAUI Application using Appium and xUnit.md"
    },
    {
      "hash": "sha256-JLtuF1ifFUtzFXw1lUDAr6WmDNjxUclXYcI1l1qAHus=",
      "url": "data/The first project with .NET MAUI.md"
    },
    {
      "hash": "sha256-yd+1pj/fIrEj+zUDvRjCTlD7Aw74hBRCk4kVxNxV7dM=",
      "url": "data/Turn any phone into an IP Camera in 30 Minutes using .NET MAUI.md"
    },
    {
      "hash": "sha256-oO04CQtrlwpWxi5IILH1rVoTTVi7yQ7zw+G9J47mkmk=",
      "url": "data/Various methods for barcode scanning in .NET MAUI.md"
    },
    {
      "hash": "sha256-oks8GFzEMw5uWT8PFvoTbObXEL7lOFMrlWP3tlD4Bbo=",
      "url": "data/categories.json"
    },
    {
      "hash": "sha256-mbJISKLiSqtxiTjF4UbyXUGN/WbMB+phYYBvFj/ZuUQ=",
      "url": "data/events.json"
    },
    {
      "hash": "sha256-zTYtwJb8l23iYQ7M+Fi1C0UG8GLMy4P+vI0H2vfWlEQ=",
      "url": "data/projects.json"
    },
    {
      "hash": "sha256-V0bTWkL0xHwMpIjIigtJkxa609A6wHxG3XYaCNCVWVY=",
      "url": "data/publications.json"
    },
    {
      "hash": "sha256-004khrMehMTupS01HSLHi0X8gx3leu6362CbWaXa0Vc=",
      "url": "data/theses.json"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-kOkqFcD6qD/IcJU/B1WRf7iL5z//A5IgEZBw6uy4w7U=",
      "url": "index.html"
    },
    {
      "hash": "sha256-xTetD6KFwBZX5FVa6s4yfPM40g7CKicCaNXiFG7leXo=",
      "url": "js/PureSnow.js"
    },
    {
      "hash": "sha256-mbjoJpKjKV+o2l1v80ppq3dk++Y9O7tcc0dI8+64Du4=",
      "url": "js/VladislavAntonyuk.js"
    },
    {
      "hash": "sha256-pjdAvO/BFoltk+5hL8oMuJwzcZfHaxwprCoq0ClIxQM=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-X9zrZFjgTF9j0G/oU4n1wvv/v1Wa+0GWvqJ/ntK1ehQ=",
      "url": "robots.txt"
    }
  ]
};
